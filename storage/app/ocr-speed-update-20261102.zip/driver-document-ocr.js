(function () {
    'use strict';
    let libraryPromise;
    let queue = Promise.resolve();
    let idleWorker = null;
    function discardIdleWorker() {
        if (!idleWorker) return;
        const entry = idleWorker;
        idleWorker = null;
        clearTimeout(entry.timer);
        entry.worker.terminate().catch(() => {});
    }
    function takeIdleWorker(key, factory, progress) {
        if (!idleWorker) return null;
        if (idleWorker.key !== key || idleWorker.factory !== factory) {
            discardIdleWorker();
            return null;
        }
        const entry = idleWorker;
        idleWorker = null;
        clearTimeout(entry.timer);
        entry.progress = progress;
        return entry;
    }
    function keepIdleWorker(entry) {
        discardIdleWorker();
        entry.progress = null;
        idleWorker = entry;
        entry.timer = setTimeout(() => {
            if (idleWorker === entry) discardIdleWorker();
        }, 30000);
    }
    window.addEventListener('pagehide', discardIdleWorker);
    const disabledForReading = new WeakMap();
    function disableFollowingFields(form, sourceInput, panel, scanInputs) {
        if (!document.getElementById('ocr-disabled-field-style')) {
            const style = document.createElement('style');
            style.id = 'ocr-disabled-field-style';
            style.textContent = `
                [data-ocr-disabled] {
                    opacity: 1 !important;
                    cursor: not-allowed !important;
                    background-color: #edf0f4 !important;
                    color: #64748b !important;
                    -webkit-text-fill-color: #64748b !important;
                    border: 1px solid #cbd5e1 !important;
                    box-shadow: none !important;
                }
                [data-ocr-disabled]::placeholder {
                    color: #8491a3 !important;
                    -webkit-text-fill-color: #8491a3 !important;
                    opacity: 1 !important;
                }
                button[data-ocr-disabled], input[type="submit"][data-ocr-disabled] {
                    background-color: #e2e8f0 !important;
                    color: #64748b !important;
                    border-color: #b8c4d3 !important;
                }
            `;
            document.head.appendChild(style);
        }
        const locked = [];
        const sourceGroup = sourceInput.closest('.form-group, .add-child-upload-card');
        const pairedControls = new Set();
        for (const pairedInput of scanInputs) {
            if (pairedInput === sourceInput) continue;
            pairedControls.add(pairedInput);
            const group = pairedInput.closest('.form-group, .add-child-upload-card');
            if (group && group !== sourceGroup) {
                group.querySelectorAll('input, select, textarea, button').forEach(field => pairedControls.add(field));
            }
        }
        for (const field of form.querySelectorAll('input, select, textarea, button, fieldset')) {
            if (field.type === 'hidden' || panel.contains(field)) continue;
            if (sourceGroup && sourceGroup.contains(field)) continue;
            if (!(sourceInput.compareDocumentPosition(field) & Node.DOCUMENT_POSITION_FOLLOWING)
                && !pairedControls.has(field) && field.type !== 'submit') continue;
            if (field === sourceInput) continue;
            let state = disabledForReading.get(field);
            if (!state) {
                state = {count: 0, disabled: field.disabled};
                disabledForReading.set(field, state);
            }
            state.count++;
            field.disabled = true;
            field.setAttribute('data-ocr-disabled', '');
            locked.push(field);
        }
        const blockSubmit = event => { event.preventDefault(); event.stopImmediatePropagation(); };
        form.addEventListener('submit', blockSubmit, true);
        let released = false;
        return () => {
            if (released) return;
            released = true;
            form.removeEventListener('submit', blockSubmit, true);
            for (const field of locked) {
                const state = disabledForReading.get(field);
                if (--state.count) continue;
                field.disabled = state.disabled;
                field.removeAttribute('data-ocr-disabled');
                disabledForReading.delete(field);
            }
        };
    }
    function showDocumentError(message, panel, sourceInput, preserveMessage = false) {
        if (panel && !preserveMessage && !message) {
            const type = panel.dataset.documentType;
            const map = String(panel.dataset.fieldMap || '');
            const owner = /father_name|father_aadhaar_number/.test(map) ? 'Father '
                : /mother_name|mother_aadhaar_number/.test(map) ? 'Mother '
                : /child_name|child_aadhaar_number/.test(map) ? 'Child ' : 'Driver ';
            const label = type === 'aadhaar' ? owner + 'Aadhaar card'
                : type === 'license' ? 'Driving license'
                : type === 'vehicle-rc' ? 'RC book' : 'Vehicle insurance';
            const side = sourceInput && sourceInput.id !== panel.dataset.inputId ? 'back' : 'front';
            message = type === 'vehicle-insurance' ? 'Please upload valid Insurance image.' : `Please upload valid ${label} ${side} side.`;
        }
        if (window.Swal && typeof window.Swal.fire === 'function') {
            window.Swal.fire({
                icon: 'error',
                text: message,
                confirmButtonText: 'OK'
            });
        } else if (typeof window.notify === 'function') {
            window.notify('error', message);
        }
    }
    const script = url => new Promise((resolve, reject) => {
        const element = document.createElement('script');
        element.src = url;
        element.onload = resolve;
        element.onerror = () => { element.remove(); reject(new Error('Reading tools could not load. Please retry or enter the details manually.')); };
        document.head.appendChild(element);
    });
    async function loadTools(base) {
        if (!libraryPromise) libraryPromise = script(base + 'tesseract/tesseract.min.js').catch(error => { libraryPromise = null; throw error; });
        await libraryPromise;
    }
    async function availableLanguages(base, type) {
        // Only English trained data is shipped. Aadhaar's English details
        // must use the same model on every PC, without probing absent files.
        return 'eng';
    }
    let standardSimdSupported;
    function aadhaarCorePath(base) {
        if (standardSimdSupported === undefined) {
            try {
                // Same standard-SIMD feature probe as the bundled Tesseract worker.
                standardSimdSupported = WebAssembly.validate(new Uint8Array([0,97,115,109,1,0,0,0,1,5,1,96,0,1,123,3,2,1,0,10,10,1,8,0,65,0,253,15,253,98,11]));
            } catch (_) { standardSimdSupported = false; }
        }
        return base + (standardSimdSupported ? 'core/tesseract-core-simd-lstm.wasm.js' : 'core/tesseract-core-lstm.wasm.js');
    }
    async function imageCanvas(file, documentType, fastPreview = false) {
        const url = URL.createObjectURL(file);
        try {
            const img = new Image();
            img.src = url;
            await img.decode();
            if (!img.naturalWidth || !img.naturalHeight || img.naturalWidth * img.naturalHeight > 50000000) throw new Error('Image is too large. Upload a smaller, clear image.');
            const enhancedDocument = documentType === 'license' || documentType === 'vehicle-rc' || documentType === 'vehicle-insurance';
            const isLicense = documentType === 'license';
            const maxSide = isLicense ? 3000 : (enhancedDocument ? 3600 : 2600);
            const maxScale = isLicense ? 3 : (enhancedDocument ? 4 : 2);
            // Keep Aadhaar at its native resolution for the initial reads.
            // Enlarged/contrast crops are separate fallbacks, never the upload.
            const longestSide = Math.max(img.naturalWidth, img.naturalHeight);
            const previewScale = documentType === 'license' ? Math.min(1, 1600 / longestSide) : Math.min(1.5, 2200 / longestSide);
            const scale = fastPreview ? previewScale
                : documentType === 'aadhaar' ? 1 : Math.min(maxScale, maxSide / longestSide);
            const canvas = document.createElement('canvas');
            canvas.width = Math.round(img.naturalWidth * scale);
            canvas.height = Math.round(img.naturalHeight * scale);
            const ctx = canvas.getContext('2d');
            ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, canvas.width, canvas.height);
            if (isLicense) {
                ctx.filter = 'contrast(150%) brightness(108%)';
            } else if (enhancedDocument) {
                ctx.filter = 'grayscale(100%) contrast(160%) brightness(110%)';
            }
            ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
            ctx.filter = 'none';
            return canvas;
        } catch (error) {
            throw new Error('This image could not be read. Use a clear JPG, PNG, WEBP, BMP, GIF or PDF.');
        } finally { URL.revokeObjectURL(url); }
    }
    function cropCanvas(source, xRatio, yRatio, widthRatio, heightRatio, scaleMultiplier, mildContrast) {
        const sourceWidth = source.width;
        const sourceHeight = source.height;
        const sx = Math.max(0, Math.round(sourceWidth * xRatio));
        const sy = Math.max(0, Math.round(sourceHeight * yRatio));
        const sw = Math.min(sourceWidth - sx, Math.round(sourceWidth * widthRatio));
        const sh = Math.min(sourceHeight - sy, Math.round(sourceHeight * heightRatio));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(sw * scaleMultiplier));
        canvas.height = Math.max(1, Math.round(sh * scaleMultiplier));
        const ctx = canvas.getContext('2d');
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.filter = mildContrast === 'original' ? 'none'
            : (mildContrast ? 'grayscale(100%) contrast(120%) brightness(105%)' : 'grayscale(100%) contrast(190%) brightness(115%)');
        ctx.drawImage(source, sx, sy, sw, sh, 0, 0, canvas.width, canvas.height);
        ctx.filter = 'none';
        if (mildContrast && mildContrast !== 'raw' && mildContrast !== 'original') {
            // Otsu threshold separates printed text from a photographed grey background.
            const pixels = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const histogram = new Array(256).fill(0);
            for (let i = 0; i < pixels.data.length; i += 4) histogram[pixels.data[i]]++;
            const count = canvas.width * canvas.height;
            const sum = histogram.reduce((total, amount, level) => total + amount * level, 0);
            let backgroundCount = 0, backgroundSum = 0, bestVariance = 0, threshold = 128;
            for (let level = 0; level < 256; level++) {
                backgroundCount += histogram[level];
                backgroundSum += histogram[level] * level;
                const foregroundCount = count - backgroundCount;
                if (!backgroundCount || !foregroundCount) continue;
                const difference = backgroundSum / backgroundCount - (sum - backgroundSum) / foregroundCount;
                const variance = backgroundCount * foregroundCount * difference * difference;
                if (variance > bestVariance) { bestVariance = variance; threshold = level; }
            }
            threshold *= 0.5;
            for (let i = 0; i < pixels.data.length; i += 4) {
                const value = pixels.data[i] <= threshold ? 0 : 255;
                pixels.data[i] = pixels.data[i + 1] = pixels.data[i + 2] = value;
            }
            ctx.putImageData(pixels, 0, 0);
        }
        return canvas;
    }
    function licenseTextCanvas(source) {
        const canvas = document.createElement('canvas');
        canvas.width = source.width;
        canvas.height = source.height;
        const ctx = canvas.getContext('2d', {willReadFrequently: true});
        ctx.fillStyle = '#fff';
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(source, 0, 0);
        const image = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const pixels = image.data;
        for (let i = 0; i < pixels.length; i += 4) {
            // Security lines are commonly orange/red. Their red channel is
            // light, while the printed licence number remains dark.
            const value = pixels[i] < 165 ? 0 : 255;
            pixels[i] = pixels[i + 1] = pixels[i + 2] = value;
        }
        ctx.putImageData(image, 0, 0);
        return canvas;
    }
    function readableAadhaarValue(value, readings) {
        const normalize = text => String(text || '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
        const candidate = normalize(value);
        if (!candidate) return false;
        for (const reading of readings) {
            const digits = String(value || '').replace(/\D/g, '');
            if (/^[\d\s-]+$/.test(value) && digits.length === 12) {
                const scanned = DriverDocumentParser.parse(reading.text, 'aadhaar').adher_no.replace(/\D/g, '');
                if (reading.confidence >= 60 && scanned === digits) return true;
                continue;
            }
            const words = String(reading.tsv || '').trim().split('\n').slice(1)
                .map(line => line.split('\t')).filter(word => word[0] === '5' && word[11]);
            const text = words.length
                ? words.map(word => Number(word[10]) >= 60 ? word[11] : 'unreadableword').join(' ')
                : reading.confidence >= 60 ? reading.text : '';
            if ((' ' + normalize(text) + ' ').includes(' ' + candidate + ' ')) return true;
        }
        return false;
    }
    function reliableAadhaarName(readings) {
        const candidates = new Map();
        for (const reading of readings) {
            const name = DriverDocumentParser.parse(reading.text, 'aadhaar').driver_name;
            if (!name || !readableAadhaarValue(name, [reading, reading])) continue;
            const key = name.toLowerCase().replace(/\s+/g, ' ').trim();
            const candidate = candidates.get(key) || {name, count: 0};
            candidate.count++;
            candidates.set(key, candidate);
        }
        const ranked = [...candidates.values()].sort((left, right) => right.count - left.count);
        // Compare complete names, so agreement on a prefix cannot approve extra letters.
        if (!ranked.length || (ranked[1] && ranked[1].count === ranked[0].count)) return '';
        return ranked[0].name;
    }
    function init(panel) {
        const scope = panel.closest('form') || document;
        const findInput = id => Array.from(scope.querySelectorAll('input[type="file"]')).find(element => element.id === id);
        const input = findInput(panel.dataset.inputId);
        if (!input || panel.dataset.bound) return;
        const form = input.form;
        if (!form) return;
        panel.dataset.bound = 'true';
        const extraInputs = (panel.dataset.extraInputIds || '').split(',').map(id => findInput(id.trim())).filter(Boolean);
        const scanInputs = [input, ...extraInputs];
        let activeInput = input;
        let pendingFrontFile = null;
        const status = panel.querySelector('[data-ocr-status]');
        const results = panel.querySelector('[data-ocr-results]');
        const retry = panel.querySelector('[data-ocr-retry]');
        const cancel = panel.querySelector('[data-ocr-cancel]');
        const base = panel.dataset.vendorBase;
        const type = panel.dataset.documentType;
        let labels = {};
        try {
            labels = panel.dataset.fieldMap ? JSON.parse(panel.dataset.fieldMap) : {};
        } catch (error) {
            labels = {};
        }
        // The driver's name belongs to Aadhaar, even if an older panel
        // configuration still includes it in the licence field map.
        if (type === 'license') delete labels.driver_name;
        const fields = Object.fromEntries(Object.keys(labels).map(key => [key, form.querySelector(`[name="${key}"]`)]));
        if (type === 'license' && fields.license_no && !panel.dataset.initialDocumentNumber) {
            panel.dataset.initialDocumentNumber = String(fields.license_no.value || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        }
        if (type === 'vehicle-rc' && !panel.dataset.initialDocumentNumber) {
            const savedRcNumber = fields.rc_number || fields.vehicle_number;
            panel.dataset.initialDocumentNumber = String(savedRcNumber ? savedRcNumber.value : '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        }
        if (type === 'aadhaar' && !panel.dataset.initialAadhaarNumber) {
            const savedAadhaarNumber = fields.adher_no
                || fields.father_aadhaar_number
                || fields.mother_aadhaar_number
                || fields.child_aadhaar_number;
            panel.dataset.initialAadhaarNumber = String(savedAadhaarNumber ? savedAadhaarNumber.value : '').replace(/\D/g, '');
        }
        if (form && !form.dataset.documentPairValidationBound) {
            form.dataset.documentPairValidationBound = 'true';
            const stopInvalidDocumentPair = event => {
                form.querySelectorAll('.document-pair-error').forEach(error => error.remove());
                const validation = window.validateDriverDocumentPairs(form);
                if (validation.valid) return false;
                event.preventDefault();
                event.stopImmediatePropagation();
                const target = validation.target || form.querySelector(validation.selector);
                if (target) {
                    const error = document.createElement('span');
                    error.className = 'error-message document-pair-error';
                    error.style.color = 'red';
                    error.textContent = validation.message;
                    target.insertAdjacentElement('afterend', error);
                    target.scrollIntoView({behavior: 'smooth', block: 'center'});
                }
                showDocumentError(validation.message, validation.documentPanel, validation.documentInput);
                return true;
            };
            form.addEventListener('click', event => {
                const button = event.target.closest('#submitBtn, #updateBtn');
                if (!button) return;
                stopInvalidDocumentPair(event);
            }, true);
            form.addEventListener('submit', stopInvalidDocumentPair, true);
        }
        let generation = 0, active = null, cityOptionsObserver = null;
        let unlockFields = null;
        const autoFilled = {};
        const autoFilledAtEdit = {};
        const autoFilledByInput = {};
        const edits = {};
        if (!form.documentFieldSources) {
            let savedSources = null;
            try { savedSources = JSON.parse(panel.dataset.fieldSources || 'null'); } catch (_) {}
            const sources = savedSources && typeof savedSources === 'object' && !Array.isArray(savedSources) ? savedSources : {};
            form.documentFieldSources = {sources, legacy: savedSources === null && panel.dataset.existingRecord === 'true'};
        }
        const sourceState = form.documentFieldSources;
        let sourceField = form.querySelector('input[name="document_field_sources"]');
        if (!sourceField) {
            sourceField = document.createElement('input');
            sourceField.type = 'hidden'; sourceField.name = 'document_field_sources';
            form.appendChild(sourceField);
            const modelField = document.createElement('input');
            modelField.type = 'hidden'; modelField.name = 'document_field_source_model';
            modelField.value = panel.dataset.sourceModel || '';
            form.appendChild(modelField);
        }
        const syncSources = () => { sourceField.value = JSON.stringify(sourceState.sources); };
        const claimSource = key => { sourceState.sources[key] = activeInput.id; syncSources(); };
        Object.entries(fields).forEach(([key, field]) => {
            edits[key] = 0;
            if (!field) return;
            const addressField = /^(?:current_address|home_address|address_1|address_2|state|city|pincode)$/.test(key);
            if (sourceState.legacy && !Object.prototype.hasOwnProperty.call(sourceState.sources, key) && field.value) {
                sourceState.sources[key] = addressField && extraInputs[0] ? extraInputs[0].id : input.id;
            }
            const savedOwner = sourceState.sources[key];
            const owner = scanInputs.find(scanInput => savedOwner && (scanInput.id === savedOwner || scanInput.id.endsWith('_' + savedOwner)));
            if (owner) {
                sourceState.sources[key] = owner.id;
                autoFilled[key] = field.type === 'radio'
                    ? form.querySelector(`[name="${key}"]:checked`)?.value || '' : field.value;
                autoFilledAtEdit[key] = 0;
                autoFilledByInput[key] = owner;
            }
            const targets = field.type === 'radio' ? Array.from(form.querySelectorAll(`[name="${key}"]`)) : [field];
            targets.forEach(target => target.addEventListener('input', event => {
                edits[key]++;
                if (event.isTrusted) {
                    delete sourceState.sources[key];
                    syncSources();
                }
            }));
        });
        syncSources();
        const message = text => { status.textContent = text; };
        function placePanelBelow(sourceInput) {
            const fieldGroup = sourceInput && sourceInput.closest('.form-group, .add-child-upload-card');
            if (!fieldGroup) return;

            const followingPreview = fieldGroup.nextElementSibling;
            const anchor = followingPreview
                && followingPreview !== panel
                && followingPreview.classList.contains('dlt_btn_div')
                ? followingPreview
                : fieldGroup;
            anchor.insertAdjacentElement('afterend', panel);
        }
        function stop(clear, releaseFields = false) {
            generation++;
            if (releaseFields && unlockFields) { unlockFields(); unlockFields = null; }
            if (type === 'aadhaar') scanInputs.forEach(scanInput => { delete scanInput.dataset.aadhaarReading; });
            if (cityOptionsObserver) { cityOptionsObserver.disconnect(); cityOptionsObserver = null; }
            if (active) {
                active.cancelled = true;
                active.abort();
                if (active.worker) active.worker.terminate().catch(() => {});
                if (active.pdfTask) active.pdfTask.destroy().catch(() => {});
                active = null;
            }
            cancel.hidden = true;
            if (clear) { results.replaceChildren(); message(''); retry.hidden = true; }
        }
        function clearScannedPreview(clearFile) {
            const targetInput = activeInput || input;
            if (clearFile && type === 'aadhaar') {
                // A panel manages both front and back inputs. Always operate
                // on the current input; using the panel's primary input here
                // removed the front preview after a back-side OCR failure.
                const uploadGroup = targetInput.closest('.form-group, .add-child-upload-card');
                const previewGroup = uploadGroup && uploadGroup.nextElementSibling && uploadGroup.nextElementSibling.classList.contains('dlt_btn_div')
                    ? uploadGroup.nextElementSibling
                    : null;

                [uploadGroup, previewGroup].filter(Boolean).forEach(group => {
                    group.querySelectorAll('span[id*="imageName"], .add-child-file-name').forEach(el => {
                        el.textContent = '';
                    });
                    group.querySelectorAll('img').forEach(el => {
                        el.removeAttribute('src');
                        el.style.display = 'none';
                    });
                    group.querySelectorAll('button[id*="removeImageBtn"]').forEach(el => {
                        el.style.display = 'none';
                    });
                });
            }
            if (clearFile) targetInput.value = '';
        }
        function showValues(parsed, snapshot, capturedEdits, file, token) {
            // Validate the whole document before applying any of its fields.
            let vehicleError = '';
            if (type === 'vehicle-rc' || type === 'vehicle-insurance') {
                const normalize = value => String(value || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                const scanned = normalize(parsed.document_vehicle_number || parsed.vehicle_number || parsed.rc_number);
                const otherInput = form.querySelector(type === 'vehicle-insurance' ? '#rc_image' : '#insurance_image');
                const otherNumber = normalize(otherInput && otherInput.dataset.scannedVehicleNumber);
                const savedRc = form.querySelector('#rc_number');
                const vehicle = form.querySelector('#vehicle_number');
                const expected = otherNumber || (type === 'vehicle-insurance'
                    ? normalize(savedRc && savedRc.value) || normalize(vehicle && vehicle.value) : '');
                if (type === 'vehicle-insurance' && !scanned) {
                    vehicleError = 'Insurance vehicle number could not be read. Upload a clear policy showing the registration number.';
                } else if (scanned && expected && scanned !== expected) {
                    vehicleError = 'RC and insurance documents belong to different vehicles. Upload insurance and RC for the same vehicle.';
                }
            }
            const expiredField = Object.entries(fields).find(([key, field]) =>
                field && /expiry_date$/.test(key) && parsed[key]
                && typeof window.isDisplayDateBeforeToday === 'function'
                && window.isDisplayDateBeforeToday(parsed[key]));
            if (vehicleError || expiredField) {
                const error = vehicleError || `${labels[expiredField[0]]} cannot be before ${window.getTodayDisplayDate()}`;
                Object.entries(fields).forEach(([fieldKey, field]) => {
                    if (!field) return;
                    field.value = '';
                    field.classList.remove('border-info');
                    delete field.dataset.ocrPendingCity;
                    delete autoFilled[fieldKey];
                    delete autoFilledAtEdit[fieldKey];
                    delete autoFilledByInput[fieldKey];
                    field.dispatchEvent(new Event('input', {bubbles: true}));
                    field.dispatchEvent(new Event('change', {bubbles: true}));
                });
                activeInput.dataset.documentValidation = 'invalid';
                delete activeInput.dataset.scannedVehicleNumber;
                delete activeInput.dataset.scannedDocumentNumber;
                results.replaceChildren();
                message(error);
                showDocumentError(error, panel, activeInput, true);
                return;
            }
            let missingAadhaarNumber = false;
            const isExtraInput = activeInput && activeInput !== input;
            const isAadhaarBackInput = type === 'aadhaar' && isExtraInput;
            const isLicenseBackInput = type === 'license' && isExtraInput;
            const backSideSkipFields = new Set(['driver_name', 'father_name', 'mother_name', 'child_name']);
            const licenseBackSkipFields = new Set(['driver_name', 'license_no', 'license_expiry_date']);
            if (type === 'aadhaar') {
                const expectedSide = isAadhaarBackInput ? 'back' : 'front';
                if (parsed.aadhaar_side !== expectedSide) {
                    const error = parsed.aadhaar_side === 'unknown'
                        ? `Aadhaar ${expectedSide} side could not be verified. Please select a clear ${expectedSide} side image.`
                        : `Only the Aadhaar ${expectedSide} side is allowed here. Please select the ${expectedSide} side image.`;
                    delete activeInput.dataset.scannedAadhaarNumber;
                    delete activeInput.dataset.scannedDriverName;
                    delete activeInput.dataset.aadhaarSide;
                    delete activeInput.dataset.aadhaarVerified;
                    clearScannedPreview(true);
                    results.replaceChildren();
                    retry.hidden = true;
                    message(error);
                    showDocumentError(error, panel, activeInput);
                    return;
                }
            }
            const isMotherAadhaar = type === 'aadhaar' && Object.prototype.hasOwnProperty.call(fields, 'mother_aadhaar_number');
            const isFatherAadhaar = type === 'aadhaar' && Object.prototype.hasOwnProperty.call(fields, 'father_aadhaar_number');
            const requiredGender = isMotherAadhaar ? 'Female' : (isFatherAadhaar ? 'Male' : '');
            const parentLabel = isMotherAadhaar ? 'Mother' : 'Father';
            const wrongGender = parsed.gender && parsed.gender !== requiredGender;
            if (requiredGender && (wrongGender || (!isAadhaarBackInput && parsed.gender !== requiredGender))) {
                const error = wrongGender
                    ? (isMotherAadhaar ? 'Please Upload Female Docement' : 'Please Upload male docemnt')
                    : `${parentLabel} Aadhaar gender could not be verified as ${requiredGender}. Please select a clear Aadhaar front image showing ${requiredGender}.`;
                delete activeInput.dataset.scannedAadhaarNumber;
                delete activeInput.dataset.scannedDriverName;
                delete activeInput.dataset.aadhaarSide;
                delete activeInput.dataset.aadhaarVerified;
                clearScannedPreview(true);
                results.replaceChildren();
                retry.hidden = true;
                message(error);
                showDocumentError(error, panel, activeInput, Boolean(wrongGender));
                return;
            }
            if ((type === 'aadhaar' || type === 'license') && activeInput && parsed.driver_name) {
                activeInput.dataset.scannedDriverName = parsed.driver_name;
            }
            if ((type === 'aadhaar' || type === 'license') && activeInput && !isExtraInput && parsed.date_of_birth) {
                activeInput.dataset.scannedDateOfBirth = parsed.date_of_birth;
            }
            if (type === 'aadhaar' && activeInput) {
                const scannedNumber = parsed.adher_no || parsed.child_aadhaar_number || parsed.father_aadhaar_number || parsed.mother_aadhaar_number || '';
                const scannedAadhaar = String(scannedNumber).replace(/\D/g, '');
                const expectedSide = isAadhaarBackInput ? 'back' : 'front';
                if (scannedAadhaar.length !== 12) {
                    delete activeInput.dataset.scannedAadhaarNumber;
                    delete activeInput.dataset.aadhaarSide;
                    delete activeInput.dataset.aadhaarVerified;
                    // Keep the selected file. Clearing the native input here
                    // caused Laravel to report "back image is required" even
                    // though the user had selected a file. The form validator
                    // will instead stop submission until it can be verified.
                    missingAadhaarNumber = true;
                } else {
                activeInput.dataset.scannedAadhaarNumber = scannedAadhaar;
                activeInput.dataset.aadhaarSide = parsed.aadhaar_side;
                activeInput.dataset.aadhaarVerified = 'true';
                activeInput.dispatchEvent(new CustomEvent('aadhaar-number-scanned', { bubbles: true, detail: { aadhaarNumber: scannedAadhaar, side: parsed.aadhaar_side } }));
                }
            }
            if ((type === 'vehicle-rc' || type === 'vehicle-insurance') && activeInput) {
                const scannedVehicleNumber = String(parsed.document_vehicle_number || parsed.vehicle_number || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                if (scannedVehicleNumber) {
                    activeInput.dataset.scannedVehicleNumber = scannedVehicleNumber;
                    activeInput.dispatchEvent(new CustomEvent('vehicle-number-scanned', { bubbles: true, detail: { vehicleNumber: scannedVehicleNumber } }));
                }
            }
            if ((type === 'license' || type === 'vehicle-rc') && activeInput) {
                const documentNumber = String(type === 'license' ? parsed.license_no : (parsed.rc_number || parsed.vehicle_number || ''))
                    .replace(/[^A-Za-z0-9]/g, '')
                    .toUpperCase();
                if (documentNumber) {
                    activeInput.dataset.scannedDocumentNumber = documentNumber;
                    activeInput.dispatchEvent(new CustomEvent('document-number-scanned', { bubbles: true, detail: { documentNumber, documentType: type } }));
                }
            }
            results.replaceChildren();
            // Queue the scanned city before state change starts loading cities.
            if (fields.city && fields.city.tagName === 'SELECT' && parsed.city
                && edits.city === capturedEdits.city) {
                fields.city.dataset.ocrPendingCity = parsed.city;
            }
            let detected = 0;
            let filled = 0;
            for (const [key, field] of Object.entries(fields)) {
                if (isAadhaarBackInput && backSideSkipFields.has(key)) {
                    continue;
                }
                if (isLicenseBackInput && licenseBackSkipFields.has(key)) {
                    continue;
                }
                const value = parsed[key];
                if (!field) continue;
                if (!value) {
                    // A newly selected document must not leave a value that
                    // was auto-filled from the previous file. Preserve it
                    // only when the user edited that field after the scan.
                    if (autoFilled[key]
                        && autoFilledByInput[key] === activeInput
                        && edits[key] === autoFilledAtEdit[key]) {
                        field.value = '';
                        field.dispatchEvent(new Event('input', {bubbles: true}));
                        field.dispatchEvent(new Event('change', {bubbles: true}));
                        field.classList.remove('border-info');
                        delete autoFilled[key];
                        delete autoFilledAtEdit[key];
                        delete autoFilledByInput[key];
                    }
                    continue;
                }
                detected++;
                const row = document.createElement('div');
                row.className = 'small mb-2';
                const summary = document.createElement('span');
                summary.textContent = `${labels[key]}: ${value} `;
                row.appendChild(summary);
                const apply = () => {
                    if (token !== generation || activeInput.files[0] !== file) return;
                    filled++;
                    if (field.type === 'radio') {
                        const radios = Array.from(form.querySelectorAll(`[name="${key}"]`));
                        const radio = radios.find(option => String(option.value || '').toLowerCase() === String(value || '').toLowerCase());
                        if (radio) {
                            radio.checked = true;
                            radio.dispatchEvent(new Event('input', {bubbles: true}));
                            radio.dispatchEvent(new Event('change', {bubbles: true}));
                            radio.classList.add('border-info');
                        }
                        autoFilled[key] = value;
                        autoFilledAtEdit[key] = edits[key];
                        autoFilledByInput[key] = activeInput;
                        claimSource(key);
                        summary.textContent = `${labels[key]} filled. Please check the field. `;
                        return;
                    }
                    if (field.tagName === 'SELECT' && value && !Array.from(field.options).some(option => option.value === value)) {
                        field.add(new Option(value, value, true, true));
                    }
                    if (key === 'city' && field.tagName === 'SELECT') {
                        field.dataset.ocrPendingCity = value;
                    }
                    field.value = value;
                    field.dispatchEvent(new Event('input', {bubbles: true}));
                    field.dispatchEvent(new Event('change', {bubbles: true}));
                    if (key === 'city' && field.tagName === 'SELECT') {
                        setTimeout(() => {
                            if (token !== generation || activeInput.files[0] !== file
                                || edits[key] !== autoFilledAtEdit[key]) return;
                            if (!Array.from(field.options).some(option => option.value === value)) {
                                field.add(new Option(value, value, true, true));
                            }
                            field.value = value;
                            field.dispatchEvent(new Event('input', {bubbles: true}));
                            field.dispatchEvent(new Event('change', {bubbles: true}));
                            autoFilledAtEdit[key] = edits[key];
                        }, 800);
                    }
                    field.classList.add('border-info');
                    autoFilled[key] = value;
                    autoFilledAtEdit[key] = edits[key];
                    autoFilledByInput[key] = activeInput;
                    claimSource(key);
                    if (key === 'city' && field.tagName === 'SELECT' && typeof MutationObserver !== 'undefined') {
                        if (cityOptionsObserver) cityOptionsObserver.disconnect();
                        cityOptionsObserver = new MutationObserver(() => {
                            if (token !== generation || activeInput.files[0] !== file
                                || edits[key] !== autoFilledAtEdit[key] || field.value === value) return;
                            if (!Array.from(field.options).some(option => option.value === value)) {
                                field.add(new Option(value, value));
                            }
                            field.value = value;
                            field.dispatchEvent(new Event('change', {bubbles: true}));
                        });
                        cityOptionsObserver.observe(field, {childList: true, subtree: true});
                    }
                    summary.textContent = `${labels[key]} filled. Please check the field. `;
                };
                const currentRadio = field.type === 'radio' ? form.querySelector(`[name="${key}"]:checked`) : null;
                const replaceSavedDocumentValue = (
                    (type === 'aadhaar'
                        && (field.value === snapshot[key]
                            || (key === 'city' && field.dataset.ocrPendingCity === value)))
                    ||
                    (type === 'license'
                        && !isLicenseBackInput
                        && (key === 'license_no' || key === 'license_expiry_date'))
                    || (type === 'vehicle-insurance'
                        && (key === 'insurance_number' || key === 'insurance_expiry_date'))
                ) && edits[key] === capturedEdits[key];
                if (field.type === 'radio' && !currentRadio) apply();
                else if (!snapshot[key].trim() && field.value === snapshot[key] && edits[key] === capturedEdits[key]) apply();
                else if (autoFilled[key] && edits[key] === autoFilledAtEdit[key]) apply();
                else if (replaceSavedDocumentValue) apply();
                else if (field.value !== value) {
                    const button = document.createElement('button');
                    button.type = 'button'; button.className = 'btn btn-sm btn-outline-primary ml-2';
                    button.textContent = 'Use scanned value';
                    button.addEventListener('click', () => { apply(); button.remove(); });
                    row.appendChild(button);
                }
                results.appendChild(row);
            }
            if (isLicenseBackInput && activeInput && activeInput.dataset.scannedDocumentNumber && !detected) {
                const row = document.createElement('div');
                row.className = 'small mb-2';
                const summary = document.createElement('span');
                summary.textContent = `License Number verified from back side: ${activeInput.dataset.scannedDocumentNumber}`;
                row.appendChild(summary);
                results.appendChild(row);
                detected = 1;
            }
            const expected = Object.entries(fields).filter(([key, field]) => {
                if (!field) return false;
                if (isAadhaarBackInput && backSideSkipFields.has(key)) return false;
                if (isLicenseBackInput && licenseBackSkipFields.has(key)) return false;
                return true;
            }).length;
            if (!detected) {
                message(isLicenseBackInput
                    ? 'License back side could not be verified. Upload a clearer back side showing the license number, or enter/check the details manually.'
                    : 'No reliable details found. Try a clearer image, the other side, or enter the details manually.');
            } else if (isLicenseBackInput) {
                message('License back side verified. Front-side details were kept unchanged.');
            } else if (filled === detected) {
                message(`${detected} of ${expected} details found and filled. Please review the fields.`);
            } else if (filled > 0) {
                message(`${detected} of ${expected} details found. New scanned values were filled; manually edited values were kept.`);
            } else {
                message(`${detected} of ${expected} details found. Review the fields; existing values were kept.`);
            }
            if (type === 'vehicle-rc' && !isExtraInput && (!parsed.vehicle_number || !parsed.rc_number)) {
                const missingMessage = ' RC number / vehicle number was not found. Please upload the RC book front side; driving licence or other documents will not fill RC details.';
                message(status.textContent + missingMessage);
            }
            if (parsed.ambiguous.length) message(status.textContent + ' Multiple possible values found; check those fields manually.');
            if (missingAadhaarNumber) message(status.textContent + ' Aadhaar number could not be read. Upload a clearer, unmasked image before submitting.');
            if (type === 'aadhaar' && parsed.address_requires_manual_review) {
                message(status.textContent + ' Address text was unclear, so it was not auto-filled. Upload a clearer Aadhaar back side or enter the address manually.');
            }
            // OCR can fail on a valid uploaded document. Keep both selected
            // files and their previews so the user can retry/replace only the
            // relevant side; never remove the front when scanning the back.
        }
        function start() {
            stop(true, true);
            const sourceInput = activeInput || input;
            const file = sourceInput.files && sourceInput.files[0];
            if (!file) return;
            const unlock = disableFollowingFields(form, sourceInput, panel, scanInputs);
            unlockFields = unlock;
            sourceInput.dataset.documentValidation = 'pending';
            Object.entries(fields).forEach(([key, field]) => {
                if (field && autoFilledByInput[key] === sourceInput && field.value === autoFilled[key]
                    && edits[key] === autoFilledAtEdit[key]) {
                    field.value = '';
                    field.dispatchEvent(new Event('change', {bubbles: true}));
                    delete autoFilled[key];
                    delete autoFilledAtEdit[key];
                    delete autoFilledByInput[key];
                }
            });
            placePanelBelow(sourceInput);
            if (type === 'vehicle-rc' || type === 'vehicle-insurance') delete sourceInput.dataset.scannedVehicleNumber;
            if (type === 'license' || type === 'vehicle-rc') delete sourceInput.dataset.scannedDocumentNumber;
            if (type === 'vehicle-rc') delete sourceInput.dataset.scannedRcIdentity;
            if (type === 'aadhaar' || type === 'license') delete sourceInput.dataset.scannedDriverName;
            if (type === 'aadhaar' || type === 'license') delete sourceInput.dataset.scannedDateOfBirth;
            if (type === 'aadhaar') {
                delete sourceInput.dataset.scannedAadhaarNumber;
                delete sourceInput.dataset.aadhaarSide;
                delete sourceInput.dataset.aadhaarVerified;
                for (const [key, field] of Object.entries(fields)) {
                    if (!field || autoFilledByInput[key] !== sourceInput || edits[key] !== autoFilledAtEdit[key]) continue;
                    if (field.type === 'radio') {
                        form.querySelectorAll(`[name="${key}"]`).forEach(radio => { radio.checked = false; });
                    } else {
                        field.value = '';
                    }
                    delete field.dataset.ocrPendingCity;
                    field.dispatchEvent(new Event('input', {bubbles: true}));
                    field.dispatchEvent(new Event('change', {bubbles: true}));
                    field.classList.remove('border-info');
                    delete autoFilled[key];
                    delete autoFilledAtEdit[key];
                    delete autoFilledByInput[key];
                }
            }
            retry.hidden = false;
            if (file.size > 20 * 1024 * 1024) { message('Use a file smaller than 20 MB for auto-fill.'); return; }
            if (!/\.(jpe?g|png|webp|bmp|gif|pdf)$/i.test(file.name)) {
                message('Auto-fill supports JPG, PNG, WEBP, BMP, GIF and PDF. Convert other file types first.'); return;
            }
            const token = generation;
            if (type === 'aadhaar') sourceInput.dataset.aadhaarReading = 'true';
            const snapshot = Object.fromEntries(Object.entries(fields).map(([key, field]) => [key, field ? field.value : '']));
            const capturedEdits = {...edits};
            cancel.hidden = false;
            message(`Document se details read ho rahi hain… (${file.name})`);
            queue = queue.catch(() => {}).then(async () => {
                if (token !== generation || activeInput.files[0] !== file) return;
                const job = {worker: null, workerEntry: null, reusable: false, pdfTask: null, cancelled: false};
                const cancelled = new Promise((_, reject) => { job.abort = () => reject(new Error('Reading cancelled.')); });
                active = job;
                let timeout;
                const current = () => !job.cancelled && token === generation && activeInput.files[0] === file;
                const ensureCurrent = () => { if (!current()) throw new Error('Reading cancelled.'); };
                let confirmedAadhaarNumber = '';
                const aadhaarReadings = [];
                const documentReadings = [];
                let focusedAddress = null;
                let focusedLicenseName = '';
                let addressRegionAttempted = false;
                async function read() {
                    let worker;
                    let aadhaarLayout = '';
                    let licenseLayout = '';
                    let lastConfidence = 0;
                    let addressConfidence = -1;
                    let parseAddress = text => DriverDocumentParser.parse(text, 'aadhaar');
                    function considerAddress(text) {
                        const candidate = parseAddress(text);
                        if (candidate.current_address && candidate.pincode && candidate.state
                            && !candidate.address_requires_manual_review && lastConfidence > addressConfidence
                            && text.toLowerCase().includes(candidate.state.toLowerCase())) {
                            focusedAddress = candidate;
                            addressConfidence = lastConfidence;
                        }
                    }
                    function aadhaarReadComplete(text) {
                        if (type !== 'aadhaar' || !confirmedAadhaarNumber) return false;
                        const side = sourceInput === input ? 'front' : 'back';
                        const candidate = DriverDocumentParser.parse(text, type);
                        candidate.adher_no = confirmedAadhaarNumber;
                        if (!DriverDocumentParser.validateDocument(text, type, side, candidate).valid
                            || !readableAadhaarValue(confirmedAadhaarNumber, aadhaarReadings)) return false;
                        if (side === 'front') {
                            const name = reliableAadhaarName(aadhaarReadings);
                            const matchingNames = aadhaarReadings.filter(reading => {
                                const found = DriverDocumentParser.parse(reading.text, type).driver_name;
                                return found && found.toLowerCase() === name.toLowerCase()
                                    && readableAadhaarValue(found, [reading]);
                            });
                            return Boolean(name && matchingNames.length >= 2
                                && candidate.date_of_birth && candidate.gender
                                && readableAadhaarValue(candidate.date_of_birth, aadhaarReadings)
                                && readableAadhaarValue(candidate.gender, aadhaarReadings));
                        }
                        return Boolean(focusedAddress && addressConfidence >= 60
                            && focusedAddress.current_address && focusedAddress.state && focusedAddress.pincode
                            && readableAadhaarValue(focusedAddress.current_address, aadhaarReadings));
                    }
                    function otherDocumentReadComplete(text, requiredReads = 2) {
                        if (!['license', 'vehicle-rc', 'vehicle-insurance'].includes(type)) return false;
                        const side = sourceInput === input ? 'front' : 'back';
                        const candidate = DriverDocumentParser.parse(text, type);
                        if (!DriverDocumentParser.validateDocument(text, type, side, candidate).valid) return false;
                        const required = type === 'license' && side === 'back' ? ['license_no']
                            : Object.keys(fields).filter(key => fields[key]);
                        if (type === 'vehicle-insurance') required.push('document_vehicle_number');
                        if (type === 'license' && side === 'front') required.push('driver_name', 'date_of_birth');
                        if (!required.length || required.some(key => !candidate[key] || candidate.ambiguous.includes(key))) return false;
                        const compact = value => String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
                        const reliable = documentReadings.filter(reading => reading.confidence >= 85);
                        // Ambiguous or conflicting evidence must keep the full fallback.
                        if (reliable.some(reading => required.some(key => reading.parsed[key]
                            && compact(reading.parsed[key]) !== compact(candidate[key])))) return false;
                        const agreeing = reliable.filter(reading => {
                            if (!DriverDocumentParser.validateDocument(reading.text, type, side, reading.parsed).valid) return false;
                            if (type === 'license' && side === 'front') {
                                const labels = reading.text.split('\n').filter(line => /\b(?:valid(?:ity)?|expir(?:y|ation|es))\b/i.test(line));
                                if (labels.length !== 1) return false;
                            }
                            const words = String(reading.tsv || '').trim().split('\n').slice(1)
                                .map(line => line.split('\t')).filter(word => word[0] === '5' && word[11]);
                            let lastLine = '';
                            const evidence = words.length ? words.map(word => {
                                const line = word.slice(1,5).join(':');
                                const separator = lastLine && line !== lastLine ? '\n' : ' ';
                                lastLine = line;
                                return separator + (Number(word[10]) >= 60 ? word[11] : 'UNREADABLE');
                            }).join('') : reading.text;
                            // Apply the existing parser's O/0 and date normalization
                            // to reliable words too; never require a different spelling
                            // from what the normal autofill path already accepts.
                            const evidenceValues = DriverDocumentParser.parse(evidence, type);
                            if (!DriverDocumentParser.validateDocument(evidence, type, side, evidenceValues).valid) return false;
                            return required.every(key => compact(reading.parsed[key]) === compact(candidate[key])
                                && compact(evidenceValues[key]) === compact(candidate[key]));
                        });
                        return agreeing.length >= requiredReads;
                    }
                    async function recognize(canvas, pageSegMode, numbersOnly) {
                        ensureCurrent();
                        if (!worker) {
                            await loadTools(base); ensureCurrent();
                            const workerLanguages = await availableLanguages(base, type);
                            const corePath = type === 'aadhaar' ? aadhaarCorePath(base) : base + 'core';
                            const progress = progress => {
                                if (current()) {
                                    message(progress.status === 'recognizing text'
                                        ? `Reading ${file.name}... ${Math.round(progress.progress * 100)}%`
                                        : `Loading reading tools for ${file.name}...`);
                                }
                            };
                            const factory = Tesseract.createWorker;
                            const key = base + '|' + corePath + '|' + workerLanguages;
                            let entry = takeIdleWorker(key, factory, progress);
                            if (entry) {
                                job.worker = entry.worker;
                                try {
                                    // Reset recognition/adaptation state between documents,
                                    // while retaining the loaded WASM and language files.
                                    await entry.worker.reinitialize(workerLanguages, 1);
                                    ensureCurrent();
                                } catch (error) {
                                    await entry.worker.terminate().catch(() => {});
                                    entry = null;
                                    job.worker = null;
                                    ensureCurrent();
                                }
                            }
                            if (!entry) {
                                entry = {key, factory, progress, worker:null};
                                entry.worker = await factory(workerLanguages, 1, {
                                    workerPath: base + 'tesseract/worker.min.js',
                                    // Keep the same core when resetting a loaded engine.
                                    corePath,
                                    langPath: base + 'lang',
                                    logger: event => { if (entry.progress) entry.progress(event); }
                                });
                            }
                            worker = entry.worker;
                            job.workerEntry = entry;
                            job.worker = worker;
                            if (!current()) { await worker.terminate(); ensureCurrent(); }
                            await worker.setParameters({preserve_interword_spaces: '1'});
                        }
                        // Aadhaar address crops are a compact text block.
                        // PSM 6 reads each line in that block more accurately
                        // than the automatic whole-document layout mode.
                        await worker.setParameters({
                            preserve_interword_spaces: '1',
                            tessedit_char_whitelist: numbersOnly === 'address'
                                ? '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz /,:.-#'
                                : numbersOnly === 'heading' ? 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz '
                                : (numbersOnly === 'date' ? '0123456789-/. ' : (numbersOnly ? '0123456789 ' : '')),
                            tessedit_pageseg_mode: String(pageSegMode || 3)
                        });
                        const {data} = await worker.recognize(canvas, {}, {text: true, tsv: true});
                        if (type === 'aadhaar') aadhaarReadings.push({text: data.text, confidence: data.confidence, tsv: data.tsv});
                        else documentReadings.push({text: data.text, confidence: data.confidence, tsv: data.tsv, parsed: DriverDocumentParser.parse(data.text, type)});
                        lastConfidence = data.confidence;
                        if (type === 'aadhaar' && pageSegMode === 11) aadhaarLayout = data.tsv || '';
                        if (type === 'license' && pageSegMode === 11) licenseLayout = data.tsv || '';
                        ensureCurrent();
                        return data.confidence >= 35 ? data.text : '';
                    }
                    if (/\.pdf$/i.test(file.name)) {
                        const pdfjs = await import(base + 'pdf/pdf.min.mjs'); ensureCurrent();
                        pdfjs.GlobalWorkerOptions.workerSrc = base + 'pdf/pdf.worker.min.mjs';
                        job.pdfTask = pdfjs.getDocument({data: new Uint8Array(await file.arrayBuffer()),
                            cMapUrl: base + 'pdf/cmaps/', cMapPacked: true, standardFontDataUrl: base + 'pdf/standard_fonts/',
                            wasmUrl: base + 'pdf/wasm/', isEvalSupported: false});
                        const pdf = await job.pdfTask.promise;
                        let text = '';
                        const pages = [];
                        for (let i = 1; i <= pdf.numPages; i++) {
                            ensureCurrent(); message(`Reading ${file.name}, PDF page ${i} of ${pdf.numPages}...`);
                            const page = await pdf.getPage(i);
                            const content = await page.getTextContent();
                            let pageText = '', lastY = null;
                            for (const item of content.items) {
                                if (typeof item.str !== 'string') continue;
                                const y = item.transform[5];
                                if (lastY !== null && Math.abs(y - lastY) > 4) pageText += '\n';
                                pageText += item.str + (item.hasEOL ? '\n' : ' '); lastY = y;
                            }
                            pages.push({number:i,text:pageText});
                            if (type === 'aadhaar' && pageText.trim()) {
                                // PDF text is extracted directly, rather than guessed from pixels.
                                aadhaarReadings.push({text: pageText, confidence: 100}, {text: pageText, confidence: 100});
                            }
                            page.cleanup();
                        }
                        // Read text from every page before deciding whether image
                        // OCR is needed. Policy terms must not trigger a full scan
                        // just because their policy number appears on another page.
                        const pdfFields = Object.keys(fields).filter(key => fields[key]);
                        const pdfBack = sourceInput !== input;
                        const requiredPdfFields = type === 'license' && pdfBack ? ['license_no']
                            : type === 'aadhaar' ? pdfFields.filter(key => pdfBack
                                ? !['driver_name','father_name','mother_name','child_name','date_of_birth','gender'].includes(key)
                                : !['current_address','home_address','address_1','address_2','state','city','pincode'].includes(key)) : pdfFields;
                        const completePdfText = (value, combined = false) => {
                            const parsed = DriverDocumentParser.parse(value, type);
                            // Do not skip OCR when text extraction has joined a
                            // short policy number to the next page's field label.
                            const policy = String(parsed.insurance_number || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                            if (combined && type === 'vehicle-insurance' && policy && !value.split(/[\r\n]+/).some(line => line.replace(/[^A-Za-z0-9]/g, '').toUpperCase().includes(policy))) return false;
                            return requiredPdfFields.every(key => parsed[key])
                                && (type !== 'vehicle-insurance' || parsed.document_vehicle_number)
                                && DriverDocumentParser.validateDocument(value, type, pdfBack ? 'back' : 'front', parsed).valid;
                        };
                        const combinedPdfComplete = completePdfText(pages.map(page => page.text).join('\n'), true);
                        for (const item of pages) {
                            ensureCurrent();
                            let pageText = item.text;
                            let needsRaster = !completePdfText(pageText);
                            if (needsRaster && pageText.trim() && combinedPdfComplete) {
                                const page = await pdf.getPage(item.number);
                                // Mixed PDFs may contain a scanned document under a
                                // text stamp. Skip only pages known to contain no images.
                                if (typeof page.getOperatorList === 'function') {
                                    const operators = await page.getOperatorList();
                                    const imageOps = ['paintImageXObject','paintInlineImageXObject','paintImageMaskXObject','paintImageXObjectRepeat','paintImageMaskXObjectRepeat','paintInlineImageXObjectGroup','paintImageMaskXObjectGroup']
                                        .map(name => pdfjs.OPS && pdfjs.OPS[name]).filter(value => value !== undefined);
                                    if (imageOps.length && !operators.fnArray.some(operation => imageOps.includes(operation))) needsRaster = false;
                                }
                                page.cleanup();
                            }
                            // Blank/scanned pages still need OCR even when a different
                            // page supplied complete text; never skip their contents.
                            if (needsRaster) {
                                message(`Reading ${file.name}, PDF page ${item.number} of ${pdf.numPages}...`);
                                const page = await pdf.getPage(item.number);
                                const viewport = page.getViewport({scale: 1});
                                const scaled = page.getViewport({scale: Math.min(3, 2600 / Math.max(viewport.width, viewport.height))});
                                const canvas = document.createElement('canvas');
                                canvas.width = Math.ceil(scaled.width); canvas.height = Math.ceil(scaled.height);
                                await page.render({canvasContext: canvas.getContext('2d'), viewport: scaled}).promise;
                                const scanned = await recognize(canvas);
                                pageText += '\n' + scanned;
                                if (type === 'aadhaar') pageText += '\n' + await recognize(canvas, 11);
                                canvas.width = canvas.height = 0;
                                page.cleanup();
                            }
                            text += '\n' + pageText;
                        }
                        return text;
                    }
                    if (['license','vehicle-insurance'].includes(type)) {
                        // Clear originals do not need the enlarged 3000-3600px
                        // canvas. Try the bounded original before the full fallback.
                        const preview = await imageCanvas(file, type, true);
                        try {
                            let previewText = await recognize(preview);
                            if (otherDocumentReadComplete(previewText, 1)) {
                                previewText += '\n' + await recognize(preview, 11);
                                if (otherDocumentReadComplete(previewText)) {
                                    if (type === 'license') focusedLicenseName = DriverDocumentParser.parse(previewText, type).driver_name;
                                    return previewText;
                                }
                            }
                        } finally { preview.width = preview.height = 0; }
                        // An unsuccessful preview must not contribute guesses or
                        // recognition state to the established detailed fallback.
                        documentReadings.length = 0;
                        licenseLayout = '';
                        if (worker && typeof worker.reinitialize === 'function') {
                            await worker.reinitialize('eng', 1);
                            ensureCurrent();
                        }
                    }
                    const canvas = await imageCanvas(file, type);
                    try {
                        const fullText = await recognize(canvas);
                        const licenseSparseText = type === 'license' ? await recognize(canvas, 11) : '';
                        let confirmedDocumentText = fullText + '\n' + licenseSparseText;
                        if (type !== 'aadhaar' && type !== 'license' && otherDocumentReadComplete(fullText, 1)) {
                            let compactRead = '';
                            if (type === 'vehicle-rc') {
                                const originalIdentity = DriverDocumentParser.rcIdentity(fullText);
                                const words = String(documentReadings[documentReadings.length - 1].tsv || '').trim().split('\n').slice(1)
                                    .map(line => line.split('\t')).filter(word => word[0] === '5' && word[11] && Number(word[8]) > 0 && Number(word[9]) > 0);
                                if (words.length && originalIdentity.registration && originalIdentity.chassis && originalIdentity.engine) {
                                    const left = Math.max(0, Math.min(...words.map(word => Number(word[6]))) - 24);
                                    const top = Math.max(0, Math.min(...words.map(word => Number(word[7]))) - 24);
                                    const right = Math.min(canvas.width, Math.max(...words.map(word => Number(word[6]) + Number(word[8]))) + 24);
                                    const bottom = Math.min(canvas.height, Math.max(...words.map(word => Number(word[7]) + Number(word[9]))) + 24);
                                    if ((right - left) * (bottom - top) < canvas.width * canvas.height * 0.8) {
                                        const count = documentReadings.length;
                                        const region = cropCanvas(canvas, left / canvas.width, top / canvas.height,
                                            (right - left) / canvas.width, (bottom - top) / canvas.height, 1, 'original');
                                        try { compactRead = await recognize(region, 11); }
                                        finally { region.width = region.height = 0; }
                                        const compactIdentity = DriverDocumentParser.rcIdentity(compactRead);
                                        if (!['registration','chassis','engine'].every(key => originalIdentity[key] === compactIdentity[key])
                                            || !otherDocumentReadComplete(fullText + '\n' + compactRead)) {
                                            // Preserve the established full-frame result if
                                            // removing margins changes any RC identity value.
                                            compactRead = '';
                                            documentReadings.length = count;
                                        }
                                    }
                                }
                            }
                            confirmedDocumentText += '\n' + (compactRead || await recognize(canvas, 11));
                        }
                        if (otherDocumentReadComplete(confirmedDocumentText)) {
                            if (type === 'license') focusedLicenseName = DriverDocumentParser.parse(confirmedDocumentText, type).driver_name;
                            return confirmedDocumentText;
                        }
                        const initialLicenseLayout = licenseLayout;
                        let licenseValidityText = '';
                        if (type === 'license') {
                            // Also read the original colours: high contrast
                            // can erase validity and back-side authority labels.
                            const validityCanvas = await imageCanvas(file, 'license-original');
                            try {
                                if (sourceInput === input) {
                                    for (const label of DriverDocumentParser.licenseNameRegions(initialLicenseLayout)) {
                                        const nameRegion = cropCanvas(validityCanvas,
                                            Math.max(0, label.x - label.height * 3) / canvas.width,
                                            (label.y + label.height * 1.2) / canvas.height,
                                            Math.min(canvas.width * 0.60, label.height * 12) / canvas.width,
                                            label.height * 2.8 / canvas.height, 1.5, 'original');
                                        try {
                                            const firstText = await recognize(nameRegion, 7);
                                            const secondText = await recognize(nameRegion, 6);
                                            const first = DriverDocumentParser.parse('Name: ' + firstText, 'license').driver_name;
                                            const second = DriverDocumentParser.parse('Name: ' + secondText, 'license').driver_name;
                                            const compactName = value => String(value || '').replace(/\s+/g, '').toUpperCase();
                                            if (first && second && compactName(first) === compactName(second)) {
                                                focusedLicenseName = second;
                                            } else {
                                                const third = DriverDocumentParser.parse('Name: ' + await recognize(nameRegion, 13), 'license').driver_name;
                                                if (third && second && compactName(third) === compactName(second)) focusedLicenseName = second;
                                                else if (third && first && compactName(third) === compactName(first)) focusedLicenseName = first;
                                            }
                                        } finally { nameRegion.width = nameRegion.height = 0; }
                                    }
                                }
                                licenseValidityText = await recognize(validityCanvas, 6);
                                licenseValidityText += '\n' + await recognize(validityCanvas, 11);
                                if (sourceInput !== input) {
                                    // Card security patterns can dominate a full-page read.
                                    // Read the lower address/signature block separately,
                                    // preserving the lighter authority/holder labels.
                                    const backDetails = cropCanvas(validityCanvas, 0, 0.48, 1, 0.52, 1.3, 'raw');
                                    try {
                                        licenseValidityText += '\n' + await recognize(backDetails, 6);
                                        licenseValidityText += '\n' + await recognize(backDetails, 11);
                                    } finally { backDetails.width = backDetails.height = 0; }
                                }
                                // Locate the printed expiry label and its date in
                                // OCR geometry; no state or fixed card position.
                                const regions = sourceInput === input
                                    ? DriverDocumentParser.licenseValidityRegions(licenseLayout) : [];
                                for (const bounds of regions) {
                                    if (!bounds.labelled) {
                                        const context = cropCanvas(validityCanvas, Math.max(0, bounds.x - bounds.height * 2) / validityCanvas.width,
                                            Math.max(0, bounds.y - bounds.height * 4) / validityCanvas.height,
                                            (bounds.width + bounds.height * 4) / validityCanvas.width,
                                            (bounds.height * 5.5) / validityCanvas.height, 2, 'original');
                                        try {
                                            licenseValidityText += '\n' + await recognize(context, 6);
                                            licenseValidityText += '\n' + await recognize(context, 11);
                                        }
                                        finally { context.width = context.height = 0; }
                                        continue;
                                    }
                                    const margin = Math.max(5, bounds.height * 0.2);
                                    const region = cropCanvas(validityCanvas, Math.max(0, bounds.x - margin) / validityCanvas.width,
                                        Math.max(0, bounds.y - margin) / validityCanvas.height,
                                        (bounds.width + margin * 2) / validityCanvas.width, (bounds.height + margin * 2) / validityCanvas.height, 2, 'raw');
                                    try {
                                        let first = DriverDocumentParser.date(await recognize(region, 7, 'date'));
                                        let second = DriverDocumentParser.date(await recognize(region, 6, 'date'));
                                        if (bounds.afterYear && (!first || first !== second)) {
                                            // OCR sometimes merges the coloured heading
                                            // and black date into one tall word box.
                                            // Re-read its lower text line separately.
                                            const dateLine = cropCanvas(validityCanvas,
                                                Math.max(0, bounds.x - bounds.height * 0.35) / validityCanvas.width,
                                                (bounds.y + bounds.height * 0.45) / validityCanvas.height,
                                                (bounds.width + bounds.height * 0.7) / validityCanvas.width,
                                                bounds.height * 0.9 / validityCanvas.height, 2, 'original');
                                            try {
                                                first = DriverDocumentParser.date(await recognize(dateLine, 7, 'date'));
                                                second = DriverDocumentParser.date(await recognize(dateLine, 6, 'date'));
                                            } finally { dateLine.width = dateLine.height = 0; }
                                        }
                                        if (first && first === second && (!bounds.afterYear || Number(first.slice(-4)) > bounds.afterYear)) {
                                            licenseValidityText += '\nValidity: ' + first;
                                        }
                                    } finally { region.width = region.height = 0; }
                                }
                            } finally { validityCanvas.width = validityCanvas.height = 0; }
                        }
                        let licenseCleanText = '';
                        let cleanLicenseNumber = '';
                        if (type === 'license' && otherDocumentReadComplete(fullText + '\n' + licenseSparseText + '\n' + licenseValidityText)) {
                            return fullText + '\n' + licenseSparseText + '\n' + licenseValidityText;
                        }
                        if (type === 'license') {
                            const cleanCanvas = licenseTextCanvas(canvas);
                            try {
                                licenseCleanText = await recognize(cleanCanvas, 11);
                            } finally {
                                cleanCanvas.width = cleanCanvas.height = 0;
                            }
                            cleanLicenseNumber = DriverDocumentParser.parse(licenseCleanText, type).license_no;
                        }
                        // Sparse-text mode is substantially better at finding
                        // Aadhaar's isolated 12-digit line when the upload is
                        // a phone screenshot with borders/empty margins.
                        const aadhaarNumberText = type === 'aadhaar' ? await recognize(canvas, 11) : '';
                        if (type === 'aadhaar') {
                            // Crops can clip the separate 16-digit VID into a
                            // plausible 12-digit number. Prefer agreement of
                            // two complete-image reads, where VID is labelled.
                            const fullNumber = DriverDocumentParser.parse(fullText, 'aadhaar').adher_no;
                            const sparseNumber = DriverDocumentParser.parse(aadhaarNumberText, 'aadhaar').adher_no;
                            if (fullNumber && fullNumber === sparseNumber) confirmedAadhaarNumber = fullNumber;
                        }
                        let focusedNameText = '';
                        let focusedBackText = '';
                        if (aadhaarLayout) {
                            const layoutWords = aadhaarLayout.trim().split('\n').slice(1).map(row => row.split('\t'))
                                .filter(row => row[0] === '5' && row[11] && Number(row[10]) >= 0);
                            const words = layoutWords.filter(row => Number(row[10]) >= 30);
                            function parseFocusedAddress(text) {
                                text = text.replace(/\b([SCDW])\s*\/\s*0\s*:/gi, '$1/O:');
                                const tokens = [...text.matchAll(/[A-Za-z]+/g)];
                                const reliable = layoutWords.filter(word => Number(word[10]) >= 85
                                    && /^[A-Za-z]+[,.:]?$/.test(word[11])).map(word => word[11].replace(/[,.:]$/, ''));
                                const oneEditApart = (left, right) => {
                                    if (Math.abs(left.length - right.length) > 1) return false;
                                    let i = 0, j = 0, differences = 0;
                                    while (i < left.length && j < right.length) {
                                        if (left[i] === right[j]) { i++; j++; continue; }
                                        if (++differences > 1) return false;
                                        if (left.length >= right.length) i++;
                                        if (right.length >= left.length) j++;
                                    }
                                    return differences + (left.length - i) + (right.length - j) === 1;
                                };
                                // Correct a letter only when an independent high-confidence
                                // pass agrees on both surrounding words.
                                for (let index = tokens.length - 2; index > 0; index--) {
                                    const token = tokens[index];
                                    const candidate = reliable.find((word, position) => position > 0 && position < reliable.length - 1
                                        && reliable[position - 1].toLowerCase() === tokens[index - 1][0].toLowerCase()
                                        && reliable[position + 1].toLowerCase() === tokens[index + 1][0].toLowerCase()
                                        && oneEditApart(word.toLowerCase(), token[0].toLowerCase()));
                                    if (candidate) text = text.slice(0, token.index) + candidate + text.slice(token.index + token[0].length);
                                }
                                text = text.replace(/([A-Z]{2,})\r?\n(?=[A-Z]{2,}\b)/g, '$1 ');
                                return DriverDocumentParser.parse(text, 'aadhaar');
                            }
                            parseAddress = parseFocusedAddress;
                            const rows = [];
                            layoutWords.forEach(word => {
                                const center = Number(word[7]) + Number(word[9]) / 2;
                                const row = rows.find(group => Math.abs(group.center - center)
                                    <= Math.max(group.height, Number(word[9])) * 0.5);
                                if (row) row.words.push(word);
                                else rows.push({center, height: Number(word[9]), words: [word]});
                            });
                            async function readRegion(regionWords, mode, numbersOnly, addressRegion) {
                                const left = Math.min(...regionWords.map(row => Number(row[6])));
                                const top = Math.min(...regionWords.map(row => Number(row[7])));
                                const right = Math.max(...regionWords.map(row => Number(row[6]) + Number(row[8])));
                                const bottom = Math.max(...regionWords.map(row => Number(row[7]) + Number(row[9])));
                                const margin = addressRegion ? 8 : Math.max(8, (bottom - top) * 0.15);
                                const letterHeights = regionWords.map(row => Number(row[9])).filter(height => height > 0).sort((a, b) => a - b);
                                const letterHeight = letterHeights[Math.floor(letterHeights.length / 2)];
                                const scale = addressRegion ? Math.max(1, Math.min(3, 40 / letterHeight)) : 2;
                                const region = cropCanvas(canvas, Math.max(0, left - margin) / canvas.width,
                                    Math.max(0, top - margin) / canvas.height,
                                    (right - left + margin * 2) / canvas.width,
                                    (bottom - top + margin * 2) / canvas.height, scale, addressRegion);
                                try { return await recognize(region, mode, addressRegion ? 'address' : numbersOnly); }
                                finally { region.width = region.height = 0; }
                            }
                            const confirmedNumbers = new Set();
                            for (const group of rows) {
                                const row = group.words;
                                const numericWords = row.filter(word => /^[0-9OoIl|]{4,16}$/.test(word[11]));
                                const length = numericWords.reduce((total, word) => total + word[11].length, 0);
                                if (length === 12 && !row.some(word => /VID/i.test(word[11]))) {
                                    const firstRead = await readRegion(numericWords, 7, true);
                                    const secondRead = await readRegion(numericWords, 6, true);
                                    focusedBackText += '\n' + firstRead + '\n' + secondRead;
                                    const firstNumber = DriverDocumentParser.parse(firstRead, 'aadhaar').adher_no;
                                    const secondNumber = DriverDocumentParser.parse(secondRead, 'aadhaar').adher_no;
                                    if (firstNumber && firstNumber === secondNumber) {
                                        confirmedNumbers.add(firstNumber);
                                    } else {
                                        // Raw-line mode avoids layout guesses around the VID/footer.
                                        const thirdRead = await readRegion(numericWords, 13, true);
                                        const thirdNumber = DriverDocumentParser.parse(thirdRead, 'aadhaar').adher_no;
                                        if (thirdNumber && (thirdNumber === firstNumber || thirdNumber === secondNumber)) {
                                            confirmedNumbers.add(thirdNumber);
                                        }
                                    }
                                }
                            }
                            if (!confirmedAadhaarNumber && confirmedNumbers.size === 1) confirmedAadhaarNumber = [...confirmedNumbers][0];
                            const addressLabel = layoutWords.find(word => /^Address[:.]?$/i.test(word[11]));
                            if (!addressLabel) {
                                const state = DriverDocumentParser.parse(layoutWords.map(word => word[11]).join('\n'), 'aadhaar').state;
                                const stateWord = words.find(word => state && word[11].toLowerCase() === state.toLowerCase());
                                if (stateWord) {
                                    addressRegionAttempted = true;
                                    const left = Math.max(0, Number(stateWord[6]) - 30);
                                    const height = Number(stateWord[9]);
                                    const top = Math.max(0, Number(stateWord[7]) - height * 3);
                                    const right = left < canvas.width * 0.3 ? canvas.width * 0.58 : canvas.width;
                                    const region = cropCanvas(canvas, left / canvas.width, top / canvas.height,
                                        (right - left) / canvas.width, height * 5.5 / canvas.height, 1.5, true);
                                    try {
                                        const addressRead = await recognize(region, 6, 'address');
                                        considerAddress(addressRead);
                                    } finally { region.width = region.height = 0; }
                                }
                            }
                            if (addressLabel) {
                                addressRegionAttempted = true;
                                const left = Number(addressLabel[6]);
                                const top = Number(addressLabel[7]);
                                const rightLimit = left < canvas.width * 0.3 ? canvas.width * 0.58 : canvas.width;
                                const belowLabel = layoutWords.filter(word => Number(word[7]) >= top
                                    && Number(word[6]) >= left - 25
                                    && Number(word[6]) + Number(word[8]) <= rightLimit);
                                const pin = belowLabel.find(word => /\b[1-9]\d{5}\b/.test(word[11]));
                                {
                                    const bottom = pin ? Number(pin[7]) + Number(pin[9])
                                        : top + Number(addressLabel[9]) * 5.5;
                                    const addressWords = belowLabel.filter(word => Number(word[7]) < bottom);
                                    // Clear scans retain their original letter strokes;
                                    // thresholding is only a fallback for grey backgrounds.
                                    for (const preprocessing of ['raw', true]) {
                                        const addressRead = await readRegion(addressWords, 6, false, preprocessing);
                                        considerAddress(addressRead);
                                        if (focusedAddress && (aadhaarReadComplete(fullText + '\n' + aadhaarNumberText + '\n' + addressRead)
                                            || addressConfidence >= 70)) {
                                            focusedBackText += '\n' + addressRead;
                                            break;
                                        }
                                    }
                                }
                            }
                            const dobWord = words.find(row => /DOB|\d{2}\/\d{2}\/\d{4}/i.test(row[11]));
                            if (dobWord) {
                                const dobY = Number(dobWord[7]);
                                const height = Number(dobWord[9]);
                                const nameWords = words.filter(row => {
                                    const y = Number(row[7]);
                                    return y < dobY && y > dobY - height * 3
                                        && /^[A-Za-z][A-Za-z.'-]*$/.test(row[11]);
                                });
                                if (nameWords.length >= 2) {
                                    const left = Math.min(...nameWords.map(row => Number(row[6])));
                                    const top = Math.min(...nameWords.map(row => Number(row[7])));
                                    const right = Math.max(...nameWords.map(row => Number(row[6]) + Number(row[8])));
                                    const bottom = Math.max(...nameWords.map(row => Number(row[7]) + Number(row[9])));
                                    const margin = Math.max(8, height * 0.4);
                                    const nameCanvas = cropCanvas(canvas, Math.max(0, left - margin) / canvas.width,
                                        Math.max(0, top - margin) / canvas.height,
                                        (right - left + margin * 2) / canvas.width,
                                        (bottom - top + margin * 2) / canvas.height, 2);
                                    try {
                                        focusedNameText = await recognize(nameCanvas, 7);
                                        focusedNameText += '\n' + await recognize(nameCanvas, 6);
                                    } finally { nameCanvas.width = nameCanvas.height = 0; }
                                }
                            }
                        }
                        if (type !== 'license' && type !== 'vehicle-rc' && type !== 'vehicle-insurance' && type !== 'aadhaar') {
                            return fullText;
                        }

                        const cropTexts = [];
                        const aadhaarText = () => focusedNameText + '\n' + focusedBackText + '\n'
                            + cropTexts.join('\n') + '\n' + aadhaarNumberText + '\n' + fullText;
                        const needsIssuer = () => {
                            const text = aadhaarText();
                            return !DriverDocumentParser.validateDocument(text, 'aadhaar', sourceInput === input ? 'front' : 'back', DriverDocumentParser.parse(text, 'aadhaar')).valid;
                        };
                        if (type === 'aadhaar' && sourceInput === input && confirmedAadhaarNumber) {
                            const candidate = DriverDocumentParser.parse(aadhaarText(), type);
                            const validation = DriverDocumentParser.validateDocument(aadhaarText(), type, 'front', candidate);
                            if (!validation.valid && /heading could not be read/.test(validation.message)) {
                                // Recover just the missing issuer before doing nine
                                // unrelated crops of an otherwise readable front.
                                const heading = cropCanvas(canvas, 0.20, 0.065, 0.78, 0.09, 3, 'original');
                                try { cropTexts.push(await recognize(heading, 7, 'heading')); }
                                finally { heading.width = heading.height = 0; }
                            }
                        }
                        // The verified number and focused name/address may already
                        // be sufficient. Keep expensive crops for missing evidence.
                        if (aadhaarReadComplete(aadhaarText())) return aadhaarText();
                        const crops = type === 'license'
                            ? [
                                () => cropCanvas(canvas, 0.00, 0.00, 1.00, 1.00, 1.35),
                                () => cropCanvas(canvas, 0.00, 0.00, 1.00, 0.65, 1.7),
                                () => cropCanvas(canvas, 0.15, 0.08, 0.80, 0.84, 1.9)
                            ]
                            : type === 'vehicle-rc'
                            ? [
                                () => cropCanvas(canvas, 0.24, 0.18, 0.34, 0.20, 2.8),
                                () => cropCanvas(canvas, 0.18, 0.14, 0.50, 0.26, 2.4),
                                () => cropCanvas(canvas, 0.00, 0.00, 1.00, 0.45, 1.7)
                            ]
                            : type === 'vehicle-insurance' ? [
                                () => cropCanvas(canvas, 0.00, 0.00, 1.00, 0.45, 1.8),
                                () => cropCanvas(canvas, 0.00, 0.20, 1.00, 0.45, 1.8),
                                () => cropCanvas(canvas, 0.45, 0.00, 0.55, 0.70, 2.0)
                            ] : [
                                // Faded issuer headings need a separate read;
                                // otherwise clear names/numbers can dominate
                                // page OCR and leave the document unidentified.
                                () => needsIssuer() ? cropCanvas(canvas, 0.00, 0.00, 1.00, 0.18, 2.0, 'raw') : null,
                                () => needsIssuer() ? cropCanvas(canvas, 0.00, 0.00, 1.00, 0.18, 2.0) : null,
                                // Aadhaar fronts vary: some place the English
                                // name closer to the photo than the address
                                // block. Read a wider upper band before the
                                // right-side crop so full names are not clipped.
                                () => cropCanvas(canvas, 0.24, 0.14, 0.74, 0.34, 3.0),
                                // Read the large number above the VID/footer,
                                // and back layouts with address left of QR.
                                () => confirmedAadhaarNumber ? null : cropCanvas(canvas, 0.20, 0.70, 0.60, 0.13, 2.4),
                                () => cropCanvas(canvas, 0.00, 0.28, 0.58, 0.25, 2.4),
                                // UIDAI cards place the English address block
                                // on the right. Read it at a higher scale so
                                // Hindi text from the left does not corrupt
                                // Address 1/Address 2.
                                () => cropCanvas(canvas, 0.42, 0.20, 0.56, 0.48, 3.0),
                                () => cropCanvas(canvas, 0.00, 0.25, 1.00, 0.75, 2.2),
                                () => cropCanvas(canvas, 0.28, 0.15, 0.72, 0.85, 2.4),
                                () => cropCanvas(canvas, 0.00, 0.00, 1.00, 1.00, 1.6)
                            ];

                        for (const pendingCrop of crops) {
                            const crop = typeof pendingCrop === 'function' ? pendingCrop() : pendingCrop;
                            if (!crop) continue;
                            try {
                                const cropText = await recognize(crop, type === 'aadhaar' ? 6 : (type === 'license' ? 11 : 3));
                                cropTexts.push(cropText);
                                if (type === 'aadhaar' && /\bAddress\s*:/i.test(cropText)) considerAddress(cropText);
                            } finally {
                                crop.width = crop.height = 0;
                            }
                            if (aadhaarReadComplete(aadhaarText())) return aadhaarText();
                            const documentText = cropTexts.join('\n') + '\n' + confirmedDocumentText + '\n' + licenseCleanText + '\n' + licenseValidityText;
                            if (otherDocumentReadComplete(documentText)) return documentText;
                        }

                        let combinedText = cropTexts.join('\n') + '\n' + licenseSparseText + '\n' + aadhaarNumberText + '\n' + fullText;
                        if (type === 'aadhaar' && sourceInput === input) {
                            // Whole-card confidence is dominated by the portrait and QR.
                            // Re-read the faded issuer separately instead of rejecting a
                            // readable number/name because its small heading was missed.
                            const preliminary = DriverDocumentParser.parse(combinedText, type);
                            if (!DriverDocumentParser.validateDocument(combinedText, type, 'front', preliminary).valid) {
                                // A block containing Gujarati/Hindi plus a faint English
                                // line can lose the issuer even when the rest is clear.
                                // Read the English strip as a single line, excluding
                                // digits so faded letters are not replaced by numbers.
                                const regions = [
                                    {x: 0.20, y: 0.065, w: 0.78, h: 0.09, mode: 7, alphabet: 'heading'},
                                    {x: 0, y: 0, w: 1, h: 0.23, mode: 6, alphabet: false}
                                ];
                                headingRetry: for (const bounds of regions) {
                                    for (const treatment of ['original', 'raw', true]) {
                                        const heading = cropCanvas(canvas, bounds.x, bounds.y, bounds.w, bounds.h, 3, treatment);
                                        try { combinedText += '\n' + await recognize(heading, bounds.mode, bounds.alphabet); }
                                        finally { heading.width = heading.height = 0; }
                                        const checked = DriverDocumentParser.parse(combinedText, type);
                                        if (DriverDocumentParser.validateDocument(combinedText, type, 'front', checked).valid) break headingRetry;
                                    }
                                }
                            }
                        }
                        if (cleanLicenseNumber) {
                            combinedText = combinedText.replace(/\b[A-Z]{2}[A-Z0-9]{8,16}\b/gi, candidate => {
                                return candidate.toUpperCase() === cleanLicenseNumber ? candidate : '';
                            });
                        }
                        return focusedNameText + '\n' + focusedBackText + '\n' + licenseCleanText + '\n' + combinedText + licenseValidityText;
                    }
                    finally { canvas.width = canvas.height = 0; }
                }
                try {
                    const text = await Promise.race([read(), cancelled, new Promise((_, reject) => {
                        // PDFs are read page by page and may legitimately take
                        // longer than an image. Cancellation remains available.
                        if (!/\.pdf$/i.test(file.name)) timeout = setTimeout(() => reject(new Error('Reading took too long. Try a smaller image or enter the details manually.')), 120000);
                    })]);
                    ensureCurrent();
                    const expectedSide = sourceInput === input ? 'front' : 'back';
                    const parsed = DriverDocumentParser.parse(text, type);
                    if (type === 'license') {
                        // Noisy full-card pattern fragments are not owner names.
                        parsed.driver_name = focusedLicenseName || parsed.driver_name;
                    }
                    if (type === 'license' && !parsed.license_no) {
                        const paired = sourceInput === input ? extraInputs[0] : input;
                        const pairedNumber = paired && paired.dataset.documentValidation === 'verified' && paired.dataset.scannedDocumentNumber;
                        if (pairedNumber && (parsed.document_number_candidates || []).includes(pairedNumber)) {
                            parsed.license_no = pairedNumber;
                            parsed.ambiguous = parsed.ambiguous.filter(key => key !== 'license_no');
                        }
                    }
                    if (type === 'aadhaar' && !confirmedAadhaarNumber && !parsed.adher_no) {
                        confirmedAadhaarNumber = DriverDocumentParser.repeatedAadhaarNumber(text);
                    }
                    if (type === 'aadhaar' && focusedAddress) {
                        ['current_address', 'home_address', 'address_1', 'address_2', 'state', 'city', 'pincode'].forEach(key => {
                            parsed[key] = focusedAddress[key];
                        });
                        parsed.address_requires_manual_review = false;
                    } else if (type === 'aadhaar' && addressRegionAttempted) {
                        ['current_address', 'home_address', 'address_1', 'address_2'].forEach(key => { parsed[key] = ''; });
                        parsed.address_requires_manual_review = true;
                    }
                    if (type === 'aadhaar' && confirmedAadhaarNumber) {
                        const numberFields = ['adher_no', 'child_aadhaar_number', 'father_aadhaar_number', 'mother_aadhaar_number'];
                        numberFields.forEach(key => { parsed[key] = confirmedAadhaarNumber; });
                        parsed.ambiguous = parsed.ambiguous.filter(key => !numberFields.includes(key));
                    }
                    if (type === 'aadhaar') {
                        const isBack = sourceInput !== input;
                        if (!isBack) {
                            const name = reliableAadhaarName(aadhaarReadings);
                            for (const key of ['driver_name', 'child_name', 'father_name', 'mother_name']) parsed[key] = name;
                        }
                        for (const key of Object.keys(fields)) {
                            if (parsed[key] && !readableAadhaarValue(parsed[key], aadhaarReadings)) parsed[key] = '';
                        }
                        const usableFields = isBack
                            ? ['current_address', 'home_address', 'address_1', 'address_2', 'adher_no', 'child_aadhaar_number', 'father_aadhaar_number', 'mother_aadhaar_number']
                            : ['driver_name', 'child_name', 'father_name', 'mother_name', 'gender', 'date_of_birth', 'adher_no', 'child_aadhaar_number', 'father_aadhaar_number', 'mother_aadhaar_number'];
                        if (!usableFields.some(key => parsed[key] && readableAadhaarValue(parsed[key], aadhaarReadings))) {
                            results.replaceChildren();
                            throw new Error(`Aadhaar ${isBack ? 'back' : 'front'} image is blurred or not clearly readable. No data was filled. Upload a clear image showing the complete number and ${isBack ? 'address' : 'name, date of birth and gender'}.`);
                        }
                    }
                    // Focused OCR can resolve a number that the combined text
                    // leaves ambiguous. Validate the final result, not an earlier pass.
                    const validation = DriverDocumentParser.validateDocument(text, type, expectedSide, parsed);
                    if (!validation.valid) {
                        sourceInput.dataset.documentValidation = 'invalid';
                        results.replaceChildren();
                        retry.hidden = false;
                        message(validation.message);
                        showDocumentError(validation.message, panel, sourceInput);
                        return;
                    }
                    const numberKey = type === 'aadhaar' ? 'adher_no' : type === 'license' ? 'license_no' : 'rc_number';
                    if (type === 'vehicle-rc') {
                        const identity = DriverDocumentParser.rcIdentity(text);
                        sourceInput.dataset.scannedRcIdentity = JSON.stringify(identity);
                        // Technical RC backs may omit registration entirely.
                        // A serial printed in the footer is not registration.
                        if (expectedSide === 'back') {
                            parsed.vehicle_number = identity.registration;
                            parsed.rc_number = identity.registration;
                            const frontIdentity = input.dataset.scannedRcIdentity ? JSON.parse(input.dataset.scannedRcIdentity) : null;
                            const pair = DriverDocumentParser.matchRcIdentity(frontIdentity, identity);
                            if (!pair.valid) {
                                sourceInput.dataset.documentValidation = 'invalid';
                                const error = pair.reason === 'mismatch'
                                    ? 'RC front and back belong to different vehicles. Upload the matching RC back side.'
                                    : 'RC back side recognized. The two images do not show a readable common registration, chassis or engine number. Upload RC images showing a matching vehicle identifier before saving.';
                                results.replaceChildren();
                                message(error);
                                if (pair.reason === 'mismatch') showDocumentError(error, panel, sourceInput);
                                return;
                            }
                        }
                    }
                    const normalizedNumber = String(parsed[numberKey] || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const sibling = sourceInput === input ? extraInputs[0] : input;
                    const siblingKey = type === 'aadhaar' ? 'scannedAadhaarNumber' : 'scannedDocumentNumber';
                    const siblingNumber = String(sibling && sibling.dataset[siblingKey] || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const savedNumber = panel.dataset.replacingDocumentPair === 'true' ? '' : String(type === 'aadhaar' ? panel.dataset.initialAadhaarNumber || '' : panel.dataset.initialDocumentNumber || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
                    const siblingSelected = Boolean(sibling && sibling.files && sibling.files.length);
                    const verifiedSiblingNumber = sibling && sibling.dataset.documentValidation === 'verified' ? siblingNumber : '';
                    if (normalizedNumber && !DriverDocumentParser.matchingSideNumber(expectedSide, normalizedNumber, verifiedSiblingNumber, siblingSelected, savedNumber)) {
                        sourceInput.dataset.documentValidation = 'invalid';
                        const error = 'Please upload valid document. Front and back must belong to the same document.';
                        results.replaceChildren();
                        message(error);
                        showDocumentError(error, panel, sourceInput);
                        return;
                    }
                    sourceInput.dataset.documentValidation = 'verified';
                    showValues(parsed, snapshot, capturedEdits, file, token);
                    job.reusable = sourceInput.dataset.documentValidation === 'verified';
                } catch (error) {
                    if (current()) {
                        const reason = error.name === 'PasswordException' ? 'Unlock the PDF before uploading, or enter the details manually.' : (error.message || 'Could not read the file. Please retry.');
                        message(reason);
                        showDocumentError(reason, panel, sourceInput, true);
                    }
                } finally {
                    clearTimeout(timeout);
                    const wasCurrent = current();
                    if (wasCurrent && sourceInput.dataset.documentValidation === 'verified') {
                        unlock();
                        if (unlockFields === unlock) unlockFields = null;
                    }
                    if (wasCurrent && sourceInput.dataset.documentValidation !== 'verified') {
                        sourceInput.dataset.documentValidation = 'invalid';
                    }
                    if (wasCurrent && type === 'aadhaar') delete sourceInput.dataset.aadhaarReading;
                    job.cancelled = true;
                    if (job.worker) {
                        if (wasCurrent && job.reusable && job.workerEntry && typeof job.worker.reinitialize === 'function') keepIdleWorker(job.workerEntry);
                        else await job.worker.terminate().catch(() => {});
                    }
                    if (job.pdfTask) await job.pdfTask.destroy().catch(() => {});
                    if (active === job) active = null;
                    if (wasCurrent) cancel.hidden = true;
                    if (wasCurrent && sourceInput === input && pendingFrontFile === file) pendingFrontFile = null;
                    // Selecting the back must not lose a front scan still needed for the name.
                    if (wasCurrent && type === 'aadhaar' && sourceInput !== input
                        && pendingFrontFile && input.files[0] === pendingFrontFile) {
                        activeInput = input;
                        start();
                    }
                }
            });
        }
        input.addEventListener('change', () => {
            if (!input.files || !input.files.length) return;
            stop(true);
            if (extraInputs.length) panel.dataset.replacingDocumentPair = 'true';
            extraInputs.forEach(backInput => {
                backInput.value = '';
                backInput.dataset.backResetByFront = 'true';
                Object.keys(backInput.dataset).forEach(key => {
                    if (/^(?:scanned|aadhaar|documentValidation)/.test(key)) delete backInput.dataset[key];
                });
                Object.entries(fields).forEach(([key, field]) => {
                    if (!field || autoFilledByInput[key] !== backInput) return;
                    if (field.value === autoFilled[key] && edits[key] === autoFilledAtEdit[key]) {
                        field.value = '';
                        field.dispatchEvent(new Event('change', {bubbles: true}));
                    }
                    delete autoFilled[key];
                    delete autoFilledAtEdit[key];
                    delete autoFilledByInput[key];
                });
                if (typeof window.clearDocumentFileUi === 'function') window.clearDocumentFileUi(backInput);
                backInput.dispatchEvent(new Event('change', {bubbles: true}));
                scope.querySelectorAll('[data-document-preview-for], [data-saved-document-preview-for]').forEach(preview => {
                    if (preview.dataset.documentPreviewFor === backInput.id) preview.remove();
                    if (preview.dataset.savedDocumentPreviewFor === backInput.id) {
                        preview.hidden = true;
                        preview.style.setProperty('display', 'none', 'important');
                    }
                });
                // Some modal forms keep their own preview inside the upload
                // card rather than using the shared preview attributes.
                const uploadGroup = backInput.closest('.form-group, .add-child-upload-card');
                if (uploadGroup) {
                    uploadGroup.querySelectorAll('img').forEach(image => {
                        image.removeAttribute('src');
                        image.style.display = 'none';
                    });
                    uploadGroup.querySelectorAll('.dlt_btn_div').forEach(preview => {
                        preview.style.setProperty('display', 'none', 'important');
                    });
                    uploadGroup.querySelectorAll('.add-child-file-name, span[id*="ImageName"], span[id*="imageName"]').forEach(name => { name.textContent = ''; });
                }
            });
        }, true);
        scanInputs.forEach(scanInput => {
            function clearUploadState(event) {
                stop(true, true);
                if (scanInput === input) pendingFrontFile = null;
                Object.entries(fields).forEach(([key, field]) => {
                    if (!field || sourceState.sources[key] !== scanInput.id) return;
                    const currentValue = field.type === 'radio'
                        ? form.querySelector(`[name="${key}"]:checked`)?.value || '' : field.value;
                    const confirmed = event?.detail?.clearedFields?.includes(key);
                    if (!confirmed && (autoFilledByInput[key] !== scanInput || currentValue !== autoFilled[key]
                        || edits[key] !== autoFilledAtEdit[key])) return;
                    if (scanInput.dataset.backResetByFront === 'true' && autoFilledByInput[key] !== scanInput) return;
                    const targets = field.type === 'radio'
                        ? Array.from(form.querySelectorAll(`[name="${key}"]`)) : [field];
                    delete autoFilled[key];
                    delete autoFilledAtEdit[key];
                    delete autoFilledByInput[key];
                    delete sourceState.sources[key];
                    targets.forEach(target => {
                        if (target.type === 'radio' || target.type === 'checkbox') target.checked = false;
                        else target.value = '';
                        delete target.dataset.ocrPendingCity;
                        target.classList.remove('border-info');
                        target.dispatchEvent(new Event('input', {bubbles: true}));
                        target.dispatchEvent(new Event('change', {bubbles: true}));
                    });
                });
                syncSources();
                Object.keys(scanInput.dataset).forEach(key => {
                    if (/^(?:scanned|aadhaar|documentValidation)/.test(key)) delete scanInput.dataset[key];
                });
            }
            scanInput.addEventListener('document-upload-cleared', clearUploadState);
            scanInput.addEventListener('change', function () {
                if (!scanInput.files || !scanInput.files.length) {
                    clearUploadState();
                    return;
                }
                delete scanInput.dataset.backResetByFront;
                if (type === 'aadhaar' && scanInput === input) {
                    pendingFrontFile = input.files[0] || null;
                    if (pendingFrontFile) {
                        for (const key of ['father_name', 'mother_name', 'child_name', 'driver_name']) {
                            const field = fields[key];
                            if (!field) continue;
                            field.value = '';
                            field.dispatchEvent(new Event('input', {bubbles: true}));
                            field.dispatchEvent(new Event('change', {bubbles: true}));
                            delete autoFilled[key];
                            delete autoFilledAtEdit[key];
                            delete autoFilledByInput[key];
                        }
                    }
                }
                activeInput = scanInput;
                start();
            });
        });
        retry.addEventListener('click', start);
        cancel.addEventListener('click', () => { stop(false); message('Reading cancelled. Please upload a valid document or retry to enable the remaining fields.'); });
        form.addEventListener('reset', () => stop(true, true));
        window.addEventListener('pagehide', () => stop(true, true));
    }
    window.validateDriverDocumentPairs = function (form) {
        const root = form || document;
        const selected = input => Boolean(input && input.files && input.files.length);
        const normalizeDocument = value => String(value || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
        const normalizeAadhaar = value => String(value || '').replace(/\D/g, '');

        for (const panel of root.querySelectorAll('.driver-document-ocr')) {
            const type = panel.dataset.documentType;
            const validationForm = panel.closest('form') || root;
            const uploadIds = [panel.dataset.inputId, ...String(panel.dataset.extraInputIds || '').split(',')].map(id => id.trim());
            for (const upload of validationForm.querySelectorAll('input[type="file"]')) {
                if (!uploadIds.includes(upload.id) || !selected(upload)) continue;
                if (upload.dataset.documentValidation && upload.dataset.documentValidation !== 'verified') {
                    return {valid: false, target: upload, selector: '#' + upload.id, documentPanel: upload.dataset.documentValidation === 'pending' ? null : panel, documentInput: upload, message: upload.dataset.documentValidation === 'pending' ? 'Please wait for document validation to finish.' : 'Please upload valid document.'};
                }
            }
            if (type !== 'license' && type !== 'aadhaar' && type !== 'vehicle-rc') continue;
            const panelForm = panel.closest('form') || root;
            const findFile = id => Array.from(panelForm.querySelectorAll('input[type="file"]')).find(element => element.id === id);
            const front = findFile(panel.dataset.inputId);
            const backId = String(panel.dataset.extraInputIds || '').split(',').map(value => value.trim()).find(Boolean);
            const back = backId ? findFile(backId) : null;
            const frontSelected = selected(front);
            const backSelected = selected(back);
            if (!frontSelected && !backSelected) continue;

            const isAadhaar = type === 'aadhaar';
            const normalize = isAadhaar ? normalizeAadhaar : normalizeDocument;
            const datasetKey = isAadhaar ? 'scannedAadhaarNumber' : 'scannedDocumentNumber';
            const initial = normalize(isAadhaar ? panel.dataset.initialAadhaarNumber : panel.dataset.initialDocumentNumber);
            const frontNumber = normalize(front && front.dataset[datasetKey]);
            const backNumber = normalize(back && back.dataset[datasetKey]);
            const fieldMap = String(panel.dataset.fieldMap || '');
            const owner = fieldMap.includes('father_name') ? 'Father'
                : fieldMap.includes('mother_name') ? 'Mother'
                : fieldMap.includes('child_name') ? 'Child' : 'Driver';
            const label = type === 'license' ? 'Driving license' : (type === 'vehicle-rc' ? 'RC book' : owner + ' Aadhaar');
            const frontUploadButton = front && root.querySelector(`button[onclick*="${front.id}"]`);
            const backUploadButton = back && root.querySelector(`button[onclick*="${back.id}"]`);
            const displayNumber = value => {
                if (!value) return 'not detected';
                if (isAadhaar) return `XXXX XXXX ${value.slice(-4)}`;
                return value;
            };
            const invalid = (message, side) => {
                const target = side === 'front'
                    ? (frontUploadButton || front)
                    : (backUploadButton || back);
                const selector = target && target.id ? `#${target.id}` : '';
                return {valid: false, selector, target, message, documentPanel: panel, documentInput: side === 'front' ? front : back};
            };

            if (isAadhaar) {
                for (const [input, isSelected, side] of [[front, frontSelected, 'front'], [back, backSelected, 'back']]) {
                    if (isSelected && input.dataset.aadhaarReading === 'true') {
                        return invalid(`${label} ${side} image is still being read. Please wait until verification finishes.`, side);
                    }
                }
            }
            if (frontSelected && back && !backSelected) {
                return invalid('Please upload the matching back side again after changing the front image.', 'back');
            }
            if (type === 'vehicle-rc' && backSelected) {
                let frontIdentity = null, backIdentity = null;
                try {
                    frontIdentity = JSON.parse(front.dataset.scannedRcIdentity || 'null');
                    backIdentity = JSON.parse(back.dataset.scannedRcIdentity || 'null');
                } catch (error) {}
                const pair = DriverDocumentParser.matchRcIdentity(frontIdentity, backIdentity);
                if (!pair.valid) return invalid(pair.reason === 'mismatch'
                    ? 'RC front and back belong to different vehicles. Upload the matching RC back side.'
                    : 'RC images must show a readable matching registration, chassis or engine number before saving.', 'back');
                continue;
            }

            if (frontSelected && !frontNumber) {
                return invalid(
                    `${label} front side is invalid: document number could not be read. Upload a clear front image of the correct ${label}.`,
                    'front'
                );
            }
            if (backSelected && !backNumber) {
                return invalid(
                    `${label} back side is invalid: document number could not be read. Upload a clear back image showing the same document number as the front side.`,
                    'back'
                );
            }
            if (isAadhaar && frontSelected && (front.dataset.aadhaarSide !== 'front' || front.dataset.aadhaarVerified !== 'true')) {
                return invalid(`Please upload a verified ${label} front side image in the ${owner} front side field.`, 'front');
            }
            if (isAadhaar && backSelected && (back.dataset.aadhaarSide !== 'back' || back.dataset.aadhaarVerified !== 'true')) {
                return invalid(`Please upload a verified ${label} back side image in the ${owner} back side field.`, 'back');
            }
            if (frontSelected && backSelected && frontNumber !== backNumber) {
                return invalid(
                    `${label} front and back do not match. Front number: ${displayNumber(frontNumber)}. Back number: ${displayNumber(backNumber)}. Upload both sides of the same document.`,
                    'back'
                );
            }
            const replacementNumber = frontSelected ? frontNumber : backNumber;
            if (!(frontSelected && backSelected) && initial && replacementNumber !== initial) {
                const replacementSide = frontSelected ? 'front' : 'back';
                return invalid(
                    `${label} ${replacementSide} side does not match the saved document. Saved number: ${displayNumber(initial)}. Uploaded ${replacementSide} number: ${displayNumber(replacementNumber)}. Upload the ${replacementSide} side of the same document.`,
                    replacementSide
                );
            }
        }
        return {valid: true};
    };
    function boot() {
        document.querySelectorAll('.driver-document-ocr').forEach(init);
        if (typeof MutationObserver !== 'undefined') {
            const observer = new MutationObserver(records => {
                records.forEach(record => record.addedNodes.forEach(node => {
                    if (node.nodeType !== 1) return;
                    if (node.matches('.driver-document-ocr')) init(node);
                    node.querySelectorAll('.driver-document-ocr').forEach(init);
                }));
            });
            observer.observe(document.body, {childList: true, subtree: true});
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
    else boot();
})();

