


<?php $__env->startSection('content'); ?>


        <div class="section-breadcrumb">
    <div class="breadcrumb-wrapper pb-0">
        <div class="container">
            <nav aria-label="breadcrumb-nav">
                <ol class="breadcrumb breadcrumb-style-2 my-20">
                    <li class="breadcrumb-item"><a class="breadcrumbLink" href="<?php echo e(route('admin_layout.index')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item breadcrumb-item-style-2 active" aria-current="page">Users</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h4 class="user-listing-header">User Listing</h4>
                </div>

        <div class="card-body">
            <!-- <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary mb-3">Add User</a> -->

            <?php
                $DatbleVariable['TableHader'] = '';
                $DatbleVariable['TableId'] = 'usersTable';
                $DatbleVariable['TableCreateRoute'] = 'users.create';
                $DatbleVariable['TableDeleteRoute'] = '';
                $DatbleVariable['TableRestoreRoute'] = '';

                $DatbleVariable['TableColumnName'] = [ 'id','Profile Picture','First Name', 'Last Name', 'Mobile', 'Email', 'Status', 'Actions'];
                $DatbleVariable['rightActionButton'] = ['createButton'];
            ?>
            <?php if (isset($component)) { $__componentOriginale217948d0aa10885800ec2994f6a95b1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale217948d0aa10885800ec2994f6a95b1 = $attributes; } ?>
<?php $component = App\View\Components\Datatable::resolve(['tablevar' => $DatbleVariable] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Datatable::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $attributes = $__attributesOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__attributesOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $component = $__componentOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__componentOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>
        </div>
    </div>
</div>

<script src="<?php echo e(asset('js/datatables_cherrypik.js')); ?>"></script>

<script>
    $(document).ready(function() {
        let tableId = "#usersTable";
        let route = '<?php echo e(route('api.userlist')); ?>';
        let id = null;
        let method = "POST";
        let leftActionButton = true;
        let searching = true;
        let deleteRoute = true;
        let graphRoute = null;
        let pagination = true;
        let restoreRoute = false;
        let distance = null;

        let inActiveVal = null;
        DatatableRenderFunction(
         tableId,
            route,
            method,
            leftActionButton,
            searching,
            distance,
            location,
            lenghtDropdown = true,
            bottomInfo = true,
            pagination,
            multiDelete = true,
            deleteRoute = "users",
            numberOfActivePost = "",
        );
    });

    $(document).on('click', '#edit', function() {
        let userId = $(this).data('id');

        $.ajax({
            url: `/api/users/${userId}/edit`,
            type: 'GET',
            success: function(response) {
                if (response.success) {
                    const user = response.data;
                    $('#first_name').val(user.first_name);
                    $('#last_name').val(user.last_name);
                    $('#mobile').val(user.mobile);
                    $('#email').val(user.email);

                    if (user.photo) {
                        $('#image-preview').attr('src', `/storage/${user.photo}`).show();
                    } else {
                        $('#image-preview').hide();
                    }

                    // Set form action to update
                    $('#userForm').attr('action', `/api/users/${userId}`);
                    $('#submitBtn').text('Update');
                } else {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error',
                        text: 'Failed to load user data.'
                    });
                }
            },
            error: function() {
                Swal.fire({
                    icon: 'error',
                    title: 'Error',
                    text: 'An unexpected error occurred.'
                });
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/users/index.blade.php ENDPATH**/ ?>