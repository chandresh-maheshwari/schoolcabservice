<!-- <div class="table-responsive">
    <table id="<?php echo e($tablevar['TableId']); ?>" class="table table-striped table-bordered" width="100%">
        <thead>
            <tr>
                <?php $__currentLoopData = $tablevar['TableColumnName']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<th><?php echo e($head); ?></th>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </thead>
    </table>
</div> -->

<div class="table-responsive">
    <div class="table-wrapper">
        <div class="section-wrapper">
            <div class="row">
                <?php if(!empty($tablevar['rightActionButton'])): ?>
                    <div class="dt-buttons action_filter1" id="action_filter_<?php echo e($tablevar['TableId']); ?>">

                        <?php if(in_array('createButton', $tablevar['rightActionButton'])): ?>
                        <?php //echo auth()->user()->can($tablevar['TableCreateRoute']);exit;?>
                            
                                <?php //echo "AAAAAAAAAAAAAAAA"; echo $tablevar['TableHader'];  exit;
                                ?>
                               
                                    <a href="<?php echo e(route($tablevar['TableCreateRoute'], $RouteParam ?? [])); ?>"
                                        id="add-btn-<?php echo e($tablevar['TableId']); ?>"
                                        class="dt-add-btn btn btn-primary btn-sm" title="Add New"
                                        ><i class="fa fa-plus"></i></a>
                                
                            
                        <?php endif; ?>

                    </div>
            </div>
            <?php endif; ?>
            <table id=<?php echo e($tablevar['TableId']); ?>

                class="table table-condensed table-striped table-bordered jambo_table bulk_action table-hover no-margin"
                width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <?php $__currentLoopData = $tablevar['TableColumnName']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $head): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($head == 'CHECKBOX'): ?>
                                <th class="wd-15p"><input type="checkbox" class="checkall" id="checkall"></th>
                                <?php continue; ?>
                            <?php elseif(str_contains($head, 'WITH CHECKBOX')): ?>
                                <th class="wd-15p"><?php echo e(str_replace('WITH CHECKBOX', '', $head)); ?><input type="checkbox"
                                        class="extraCheck" id="extraCheck"></th>
                                <?php continue; ?>
                            <?php elseif(str_contains($head, 'CHECKBOX WITH BUTTON')): ?>
                                <th class="wd-15p"><?php echo e(str_replace('CHECKBOX WITH BUTTON', '', $head)); ?><input
                                        type="checkbox" class="extraCheck" style="vertical-align: middle;"> <i
                                        class="fa fa-save" id="extraCheck"
                                        style="font-size: 20px; cursor: pointer; vertical-align: middle;"></i></th>
                                <?php continue; ?>
                            <?php endif; ?>
                            <th><?php echo e($head); ?></th>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/components/datatable.blade.php ENDPATH**/ ?>