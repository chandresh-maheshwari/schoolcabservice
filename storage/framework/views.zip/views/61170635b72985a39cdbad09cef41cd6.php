


<?php $__env->startSection('content'); ?>
    <div class="section-breadcrumb">
        <div class="breadcrumb-wrapper pb-0">
            <div class="container">
                <nav aria-label="breadcrumb-nav">
                    <ol class="breadcrumb breadcrumb-style-2 my-20">
                        <li class="breadcrumb-item breadcrumb-item-style-2 active" aria-current="page">Dashboard</li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>
<div class="container-fluid">
        <div class="row">
            <h1>WelCome School Cab Service</h1>
        </div>
        </div>
    

    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>
    
    <script>
    // document.addEventListener('DOMContentLoaded', function() {
    //     fetch('/api/writers/all-counts')
    //         .then(response => response.json())
    //         .then(data => {
    //             if (data) {
    //                 if (data.magazine_count !== undefined) {
    //                     document.getElementById('totalMagazines').textContent = data.magazine_count;
    //                 }
    //                 if (data.blog_count !== undefined) {
    //                     document.getElementById('totalBlogs').textContent = data.blog_count;
    //                 }
    //                 if (data.writers !== undefined) {
    //                     document.getElementById('totalWriters').textContent = data.writers;
    //                 }
    //                 if (data.quote_count !== undefined) {
    //                     document.getElementById('totalQuotes').textContent = data.quote_count;
    //                 }
    //                 if (data.user_count !== undefined) {
    //                     document.getElementById('totalUsers').textContent = data.user_count;
    //                 }
    //                 if (data.faq_count !== undefined) {
    //                     document.getElementById('totalFaqs').textContent = data.faq_count;
    //                 }
    //                 if (data.category_count !== undefined) {
    //                     document.getElementById('totalCategories').textContent = data.category_count;
    //                 }
    //                 if (data.contact_message_count !== undefined) {
    //                     document.getElementById('totalContactMessages').textContent = data.contact_message_count;
    //                 }
    //                 if (data.founder_count !== undefined) {
    //                     document.getElementById('totalFounders').textContent = data.founder_count;
    //                 }
    //                 if (data.authors !== undefined) {
    //                     document.getElementById('totalAuthors').textContent = data.authors;
    //                 }
    //             }
    //         })
    //         .catch(error => {
    //             console.error('Error fetching counts:', error);
    //         });


    // });
    </script>

    <script>



</script>

<?php $__env->stopSection(); ?>



<!-- Pending Blog View Modal -->


<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/admin_layout/admin_home.blade.php ENDPATH**/ ?>