


<?php $__env->startSection('content'); ?>

        <div class="section-breadcrumb">
    <div class="breadcrumb-wrapper pb-0">
        <div class="container">
            <nav aria-label="breadcrumb-nav">
                <ol class="breadcrumb breadcrumb-style-2 my-20">
                    <li class="breadcrumb-item"><a class="breadcrumbLink" href="<?php echo e(route('admin_layout.index')); ?>">Dashboard</a></li> 
                    <li class="breadcrumb-item breadcrumb-item-style-2 active" aria-current="page">Create Role</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
        <div class="container-fluid" >
    <div class="card">
        <div class="card-header" >
            <h4 class="user-listing-header">Add Role</h4>
        </div>
        <div class="card-body">
            <form id="roleForm" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name" style="font-weight: bold;">Role Name <span style="color: red;">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <button type="button" class="btn btn-primary" id="submitBtn" style="background-color: #2d336b; color: white;">Submit</button>
                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary" id="cancelBtn">Cancel</a>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.getElementById('name').addEventListener('input', function() {
        var errorMessage = document.getElementById('error-message');
        if (this.value.trim() && errorMessage) {
            errorMessage.remove();
        }
    });

    document.getElementById('submitBtn').addEventListener('click', function() {
        var nameInput = document.getElementById('name');
        var formData = new FormData(document.getElementById('roleForm'));
        var errorMessage = document.getElementById('error-message');

        if (!nameInput.value.trim()) {
            if (!errorMessage) {
                errorMessage = document.createElement('div');
                errorMessage.id = 'error-message';
                errorMessage.style.color = 'red';
                errorMessage.textContent = 'Role Name is required.';
                nameInput.parentNode.insertBefore(errorMessage, nameInput.nextSibling);
            }
            return;
        } else if (errorMessage) {
            errorMessage.remove();
        }

        Swal.fire({
            title: 'Please wait...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        fetch('<?php echo e(route('api.roles.store')); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value
            }
        })
        .then(response => response.json())
        .then(data => {
            Swal.close();
            if (data.success) {
                notify('success', 'Role created Successfully!');
                setTimeout(function() {
                    window.location.href = '<?php echo e(route('roles.index')); ?>';
                }, 1500);
            } else {
                notify('error', 'There was an error creating the role.');
            }
        })
        .catch(error => {
            Swal.close();
            notify('error', 'An unexpected error occurred.');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/roles/create.blade.php ENDPATH**/ ?>