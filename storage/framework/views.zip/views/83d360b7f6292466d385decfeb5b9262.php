  <!-- partial:partials/_footer.html -->
          <footer class="footer">
            <div class="container">
              <div class="d-sm-flex justify-content-center justify-content-sm-between">
                <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">
                  Copyright © <?php echo e(date('Y')); ?>

                  <a href="<?php echo e(config('app.site_url')); ?>" target="_blank" style="color: #2D336B;">
                    <?php echo e(config('app.site_name')); ?>

                  </a>. All rights reserved.
                </span>
                <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">Developed & Managed By Cherrypik Software, Inc.</span>
              </div>
            </div>
          </footer>
          <?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/admin_layout/footer.blade.php ENDPATH**/ ?>