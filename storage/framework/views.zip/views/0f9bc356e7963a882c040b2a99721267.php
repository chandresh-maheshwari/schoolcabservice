<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.toaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="section-breadcrumb">
        <div class="breadcrumb-wrapper pb-0">
            <div class="container">
                <nav aria-label="breadcrumb-nav">
                    <ol class="breadcrumb breadcrumb-style-2 my-20">
                        <li class="breadcrumb-item">
                            <a class="breadcrumbLink" href="<?php echo e(route('admin_layout.index')); ?>">Dashboard</a>
                        </li>
                        <li class="breadcrumb-item">
                            <a class="breadcrumbLink" href="<?php echo e(route('howItWorks.index')); ?>">How It Works</a>
                        </li>
                        <li class="breadcrumb-item breadcrumb-item-style-2 active">
                            Edit How It Works Section Detail
                        </li>
                    </ol>
                </nav>
            </div>
        </div>
    </div>

    <div class="container-fluid">
        <div class="card">
            <div class="card-header">
                <h4 class="about-us-create-header">Edit How It Works Section Details</h4>
            </div>

            <div class="card-body">
                <form id="howItWorkForm" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" id="how_it_work_id" value="<?php echo e($howItWork->id); ?>">

                    
                    <div class="form-group">
                        <label>Title <span style="color:red;">*</span></label>
                        <input type="text" class="form-control" id="title" name="title"
                               value="<?php echo e($howItWork->title); ?>" autocomplete="off">
                    </div>

                    
                    <div class="form-group">
                        <label>Name <span style="color:red;">*</span></label>
                        <input type="text" class="form-control" id="name" name="name"
                               value="<?php echo e($howItWork->name); ?>" autocomplete="off">
                    </div>

                    
                    <div class="form-group">
                        <label>Description</label>
                        <textarea class="form-control" id="description" name="description"
                                  rows="3"><?php echo e($howItWork->description); ?></textarea>
                    </div>

                    
                    <div class="form-group">
                        <label>Button Name 1 <span style="color:red;">*</span></label>
                        <input type="text" class="form-control" id="button_name_1" name="button_name_1"
                               value="<?php echo e($howItWork->button_name_1); ?>" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Button Link 1 <span style="color:red;">*</span></label>
                        <input type="url" class="form-control" id="button_link_1" name="button_link_1"
                               value="<?php echo e($howItWork->button_link_1); ?>" autocomplete="off">
                    </div>

                    
                    <div class="form-group">
                        <label>Button Name 2 <span style="color:red;">*</span></label>
                        <input type="text" class="form-control" id="button_name_2" name="button_name_2"
                               value="<?php echo e($howItWork->button_name_2); ?>" autocomplete="off">
                    </div>

                    <div class="form-group">
                        <label>Button Link 2 <span style="color:red;">*</span></label>
                        <input type="url" class="form-control" id="button_link_2" name="button_link_2"
                               value="<?php echo e($howItWork->button_link_2); ?>" autocomplete="off">
                    </div>

                    <button type="button" class="btn btn-primary" id="updateBtn">Update</button>
                    <a href="<?php echo e(route('howItWorks.index')); ?>" class="btn btn-secondary">Cancel</a>
                </form>
            </div>
        </div>
    </div>

    
    <script>
          CKEDITOR.replace('description');
        $('#updateBtn').on('click', function () {

            $('.error-message').remove();
            let formData = new FormData(document.getElementById('howItWorkForm'));
               formData.set('description', CKEDITOR.instances.description.getData());
            let id = $('#how_it_work_id').val();
            let isValid = true;

            function showError(el, msg) {
                $(el).after('<span class="error-message" style="color:red;">' + msg + '</span>');
                isValid = false;
            }

            if (!formData.get('title')) showError('#title', 'Title is required');
            if (!formData.get('name')) showError('#name', 'Name is required');
            if (!formData.get('button_name_1')) showError('#button_name_1', 'Button Name 1 is required');
            if (!formData.get('button_link_1')) showError('#button_link_1', 'Button Link 1 is required');
            if (!formData.get('button_name_2')) showError('#button_name_2', 'Button Name 2 is required');
            if (!formData.get('button_link_2')) showError('#button_link_2', 'Button Link 2 is required');

             if (!CKEDITOR.instances.description.getData().trim()) {
                $('#description').next('.cke').after(
                    '<span class="error-message" style="color: red;">Description is required.</span>');
                isValid = false;
            }
            if (!isValid) return;

            Swal.fire({
                title: 'Please wait...',
                allowOutsideClick: false,
                didOpen: () => Swal.showLoading()
            });

           formData.append('_method', 'PUT');

            fetch('<?php echo e(route('api.howItWorks.update', $howItWork->id)); ?>', {
                    method: 'POST', // Use POST with _method=PUT for file uploads in Laravel
                    body: formData,
                    headers: {
                        'X-CSRF-TOKEN': $('input[name="_token"]').val(),
                        'Accept': 'application/json'
                    }
                })
            .then(res => res.json())
            .then(data => {
                Swal.close();
                if (data.success) {
                    notify('success', 'How It Works Section updated successfully!');
                    setTimeout(() => {
                        window.location.href = '<?php echo e(route('howItWorks.index')); ?>';
                    }, 1500);
                } else {
                    notify('error', data.message || 'Something went wrong');
                }
            });
        });

        /* REAL-TIME ERROR REMOVE */
        $(document).on('input change', 'input, textarea, select', function () {
            $(this).next('.error-message').remove();
        });
         CKEDITOR.instances.description.on('change', function() {
            $('#description').next('.cke').next('.error-message').remove();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/cms/how_it_work_section/edit.blade.php ENDPATH**/ ?>