


<?php $__env->startSection('content'); ?>

        <div class="section-breadcrumb">
    <div class="breadcrumb-wrapper pb-0">
        <div class="container">
            <nav aria-label="breadcrumb-nav">
                <ol class="breadcrumb breadcrumb-style-2 my-20">
                    <li class="breadcrumb-item"><a class="breadcrumbLink" href="<?php echo e(route('admin_layout.index')); ?>">Dashboard</a></li> 
                    <li class="breadcrumb-item breadcrumb-item-style-2 active" aria-current="page">Permissions</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h4 class="permissions-listing-header">Permissions Listing</h4>
                </div>
        
        <div class="card-body">
            <?php
                $DatbleVariable['TableHader'] = '';
                $DatbleVariable['TableId'] = 'permissionsTable';
                $DatbleVariable['TableCreateRoute'] = 'permissions.create';
                $DatbleVariable['TableDeleteRoute'] = '';
                $DatbleVariable['TableRestoreRoute'] = '';

                $DatbleVariable['TableColumnName'] = ['Sr No.', 'Name', 'Actions'];
                $DatbleVariable['rightActionButton'] = ['createButton'];
            ?>
            <?php if (isset($component)) { $__componentOriginale217948d0aa10885800ec2994f6a95b1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale217948d0aa10885800ec2994f6a95b1 = $attributes; } ?>
<?php $component = App\View\Components\Datatable::resolve(['tablevar' => $DatbleVariable] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('datatable'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Datatable::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'w-100']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $attributes = $__attributesOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__attributesOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale217948d0aa10885800ec2994f6a95b1)): ?>
<?php $component = $__componentOriginale217948d0aa10885800ec2994f6a95b1; ?>
<?php unset($__componentOriginale217948d0aa10885800ec2994f6a95b1); ?>
<?php endif; ?>
        </div>
    </div>
</div>


<script src="<?php echo e(asset('js/datatables_cherrypik.js')); ?>"></script>


<script>
     $(document).ready(function() {
        let tableId = "#permissionsTable";
        let route = '<?php echo e(route('api.permissions.list')); ?>';
        let method = "POST";
        let leftActionButton = true;
        let searching = true;
        let pagination = true;
        let distance = null;

        DatatableRenderFunction(
            tableId,
            route,
            method,
            leftActionButton,
            searching,
            distance,
            location,
            lenghtDropdown = true,
            bottomInfo = true,
            pagination,
            multiDelete = true,
            deleteRoute = "hero",
            numberOfActivePost = 1,
        );
    });

    // $(document).on('click', '#edit', function() {
    //     let permissionId = $(this).data('id');

    //     $.ajax({
    //         url: `/api/permissions/${permissionId}/edit`,
    //         type: 'GET',
    //         success: function(response) {
    //             if (response.success) {
    //                 const permission = response.data;
    //                 $('#name').val(permission.name);
    //                 $('#permissionForm').attr('action', `/api/permissions/${permissionId}`);
    //                 $('#submitBtn').text('Update');
    //             } else {
    //                 Swal.fire({
    //                     icon: 'error',
    //                     title: 'Error',
    //                     text: 'Failed to load permission data.'
    //                 });
    //             }
    //         },
    //         error: function() {
    //             Swal.fire({
    //                 icon: 'error',
    //                 title: 'Error',
    //                 text: 'An unexpected error occurred.'
    //             });
    //         }
    //     });
    // });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/permissions/index.blade.php ENDPATH**/ ?>