<?php if(Session::has('success')): ?>
    <script>
        toastr.success("<?php echo e(Session::get('success')); ?>", "Success");
    </script>
<?php endif; ?>

<?php if(Session::has('error')): ?>
    <script>
        toastr.error("<?php echo e(Session::get('error')); ?>", "Error");
    </script>
<?php endif; ?>

<?php if(Session::has('info')): ?>
    <script>
        toastr.info("<?php echo e(Session::get('info')); ?>", "Info");
    </script>
<?php endif; ?>

<?php if(Session::has('warning')): ?>
    <script>
        toastr.warning("<?php echo e(Session::get('warning')); ?>", "Warning");
    </script>
<?php endif; ?>
<?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/partials/toaster.blade.php ENDPATH**/ ?>