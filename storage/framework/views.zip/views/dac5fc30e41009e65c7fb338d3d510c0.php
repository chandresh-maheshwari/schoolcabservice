



<?php $__env->startSection('content'); ?>

        <div class="section-breadcrumb">
    <div class="breadcrumb-wrapper pb-0">
        <div class="container">
            <nav aria-label="breadcrumb-nav">
                <ol class="breadcrumb breadcrumb-style-2 my-20">
                    <li class="breadcrumb-item"><a class="breadcrumbLink" href="<?php echo e(route('admin_layout.index')); ?>">Dashboard</a></li> 
                    <li class="breadcrumb-item"><a class="breadcrumbLink" href="<?php echo e(route('permissions.index')); ?>">Permissions</a></li>
                    <li class="breadcrumb-item breadcrumb-item-style-2 active" aria-current="page">Edit Permission</li>
                </ol>
            </nav>
        </div>
    </div>
</div>
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h2 class="user-listing-header">Edit Permission</h2>
                </div>
        <div class="card-body">
            <form id="permissionForm">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="name" style="font-weight: bold;">Permission Name <span style="color: red;">*</span></label>
                    <input type="text" class="form-control" id="name" name="name" value="<?php echo e($permission->name); ?>" required>
                </div>
                <button type="button" class="btn btn-primary" id="submitBtn" style="background-color: #2C9DD4; color: white;">Update</button>
                <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-secondary" id="cancelBtn">Cancel</a>
            </form>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script>
    document.getElementById('name').addEventListener('input', function() {
        var errorMessage = document.getElementById('error-message');
        if (this.value.trim() && errorMessage) {
            errorMessage.remove();
        }
    });

    document.getElementById('submitBtn').addEventListener('click', function() {
        var nameInput = document.getElementById('name');
        var formData = new FormData(document.getElementById('permissionForm'));
        var errorMessage = document.getElementById('error-message');

        if (!nameInput.value.trim()) {
            if (!errorMessage) {
                errorMessage = document.createElement('div');
                errorMessage.id = 'error-message';
                errorMessage.style.color = 'red';
                errorMessage.textContent = 'Permission Name is required.';
                nameInput.parentNode.insertBefore(errorMessage, nameInput.nextSibling);
            }
            return;
        } else if (errorMessage) {
            errorMessage.remove();
        }

        Swal.fire({
            title: 'Please wait...',
            allowOutsideClick: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });
        fetch('<?php echo e(route('api.permissions.update', $permission->id)); ?>', {
            method: 'POST',
            body: formData,
            headers: {
                'X-CSRF-TOKEN': document.querySelector('input[name="_token"]').value,
                'X-HTTP-Method-Override': 'PUT'
            }
        })
        .then(response => response.json())
        .then(data => {
            Swal.close();
            if (data.success) {
                Swal.close();
                notify('success', 'Permission updated Successfully!');
                setTimeout(function() {
                        window.location.href = '<?php echo e(route('permissions.index')); ?>';
                    }, 1500);
            } else {
                notify('error', 'There was an error updating the permission.');
            }
        })
        .catch(error => {
            Swal.close();
            notify('error', 'An unexpected error occurred.');
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/permissions/edit.blade.php ENDPATH**/ ?>