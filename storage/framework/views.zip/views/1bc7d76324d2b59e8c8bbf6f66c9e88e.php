<?php $__env->startSection('content'); ?>
<?php echo $__env->make('partials.toaster', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="container-fluid">
    <div class="card">
        <div class="card-header">
            <h4>Edit Route Details</h4>
        </div>

        <div class="card-body">
            <form id="routeForm">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                
                <div class="form-group">
                    <label><b>Route Name</b> <span class="text-danger">*</span></label>
                    <input type="text" class="form-control" name="name" id="name"
                        value="<?php echo e($route->name); ?>">
                    <span class="error-message text-danger"></span>
                </div>

                
                <div class="form-group">
                    <label><b>Vehicle</b> <span class="text-danger">*</span></label>
                    <select class="form-control" name="bus_id" id="bus_id">
                        <option value="">Select Vehicle</option>
                        <?php $__currentLoopData = $buses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bus): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($bus->id); ?>"
                                <?php echo e($route->bus_id == $bus->id ? 'selected' : ''); ?>>
                                <?php echo e($bus->vehicle_number); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error-message text-danger"></span>
                </div>

                
                <div class="form-group">
                    <label><b>Driver</b> <span class="text-danger">*</span></label>
                    <select class="form-control" name="driver_id" id="driver_id">
                        <option value="">Select Driver</option>
                        <?php $__currentLoopData = $drivers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $driver): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($driver->id); ?>"
                                <?php echo e($route->driver_id == $driver->id ? 'selected' : ''); ?>>
                                <?php echo e($driver->driver_name); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <span class="error-message text-danger"></span>
                </div>

                
                <div class="form-group">
                    <label><b>Edit Route on Map</b> <span class="text-danger">*</span></label>
                    <div id="map" style="height:400px;"></div>
                    <small class="text-muted">
                        👉 Click map to add more points / stops
                    </small>
                </div>

                
                <input type="hidden" name="geojson" id="geojson">
                <input type="hidden" name="stops" id="stops">

                <button type="button" class="btn btn-primary" id="updateBtn">
                    Update Route
                </button>

                <a href="<?php echo e(route('routes.index')); ?>" class="btn btn-secondary">
                    Cancel
                </a>
            </form>
        </div>
    </div>
</div>


<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAOVYRIgupAurZup5y1PRh8Ismb1A3lLao"></script>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>

<script>
let map, polyline;
let routeCoords = [];
let stops = [];
let markers = [];

const rawGeoJson = <?php echo json_encode($route->geojson ?? null, 15, 512) ?>;
const rawStops   = <?php echo json_encode($route->stops ?? [], 15, 512) ?>;

function normalizeGeoJson(data) {

    // Case 1: Already array [[lng,lat]]
    if (Array.isArray(data)) {
        return data;
    }

    // Case 2: GeoJSON object {type, coordinates}
    if (data && typeof data === 'object' && Array.isArray(data.coordinates)) {
        return data.coordinates;
    }

    return [];
}

function initMap() {

    routeCoords = normalizeGeoJson(rawGeoJson);
    stops = Array.isArray(rawStops) ? rawStops : [];

    if (routeCoords.length === 0) {
        alert('Route coordinates not found in database');
        return;
    }

    map = new google.maps.Map(document.getElementById("map"), {
        center: {
            lat: routeCoords[0][1],
            lng: routeCoords[0][0]
        },
        zoom: 13
    });

    polyline = new google.maps.Polyline({
        map: map,
        path: routeCoords.map(p => ({ lat: p[1], lng: p[0] })),
        strokeColor: "#2C9DD4",
        strokeWeight: 4
    });

    // Existing stops
    stops.forEach(stop => {
        markers.push(new google.maps.Marker({
            position: { lat: stop.lat, lng: stop.lng },
            map: map,
            title: stop.name
        }));
    });

    updateHiddenFields();

    map.addListener("click", function (e) {
        addRoutePoint(e.latLng);
    });
}

function addRoutePoint(latLng) {

    routeCoords.push([latLng.lng(), latLng.lat()]);

    polyline.setPath(
        routeCoords.map(p => ({ lat: p[1], lng: p[0] }))
    );

    markers.push(new google.maps.Marker({
        position: latLng,
        map: map
    }));

    stops.push({
        name: "Stop " + stops.length,
        lat: latLng.lat(),
        lng: latLng.lng()
    });

    updateHiddenFields();
}

function updateHiddenFields() {
    document.getElementById('geojson').value = JSON.stringify(routeCoords);
    document.getElementById('stops').value  = JSON.stringify(stops);
}

window.onload = initMap;
// window.onload = initMap;

$('#updateBtn').on('click', function () {

    let formData = new FormData(document.getElementById('routeForm'));
    let valid = true;

    $('.error-message').text('');

    if (!formData.get('name')) {
        $('#name').next('.error-message').text('Route name required');
        valid = false;
    }
    if (!formData.get('bus_id')) {
        $('#bus_id').next('.error-message').text('Vehicle required');
        valid = false;
    }
    if (!formData.get('driver_id')) {
        $('#driver_id').next('.error-message').text('Driver required');
        valid = false;
    }

    if (!valid) return;

    Swal.fire({ title: 'Updating...', didOpen: () => Swal.showLoading() });

    fetch('<?php echo e(route("routes.update", $route->id)); ?>', {
        method: 'POST',
        body: formData,
        headers: {
            'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
        }
    })
    .then(res => res.json())
    .then(data => {
        Swal.close();
        if (data.success) {
            notify('success', 'Route updated successfully');
             setTimeout(() => {
                            window.location.href = '<?php echo e(route('routes.index')); ?>';
                        }, 1500);
        } else {
            notify('error', data.message);
        }
    });
});
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin_layout.index', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp8.2\htdocs\schoolcabservice\resources\views/routes/edit.blade.php ENDPATH**/ ?>